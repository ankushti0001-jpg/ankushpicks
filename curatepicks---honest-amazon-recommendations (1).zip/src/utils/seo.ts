import { Product } from '../types';

export function updatePageSeo(title: string, description: string, product?: Product) {
  // Update document title
  document.title = title;

  // Update meta description
  let metaDesc = document.querySelector('meta[name="description"]');
  if (!metaDesc) {
    metaDesc = document.createElement('meta');
    metaDesc.setAttribute('name', 'description');
    document.head.appendChild(metaDesc);
  }
  metaDesc.setAttribute('content', description);

  // Update OG Title & Twitter
  const ogTitle = document.querySelector('meta[property="og:title"]');
  if (ogTitle) ogTitle.setAttribute('content', title);

  const ogDesc = document.querySelector('meta[property="og:description"]');
  if (ogDesc) ogDesc.setAttribute('content', description);

  const twTitle = document.querySelector('meta[name="twitter:title"]');
  if (twTitle) twTitle.setAttribute('content', title);

  const twDesc = document.querySelector('meta[name="twitter:description"]');
  if (twDesc) twDesc.setAttribute('content', description);

  // Update or inject Schema.org JSON-LD
  let scriptTag = document.getElementById('dynamic-jsonld') as HTMLScriptElement | null;
  if (!scriptTag) {
    scriptTag = document.createElement('script');
    scriptTag.id = 'dynamic-jsonld';
    scriptTag.type = 'application/ld+json';
    document.head.appendChild(scriptTag);
  }

  if (product) {
    const productSchema = {
      '@context': 'https://schema.org',
      '@type': 'Product',
      name: product.name,
      image: [product.imageUrl, ...(product.additionalImages || [])],
      description: product.shortDescription,
      sku: product.asin || product.id,
      offers: {
        '@type': 'Offer',
        url: product.affiliateUrl,
        priceCurrency: 'INR',
        price: product.price.toString(),
        availability: 'https://schema.org/InStock',
        itemCondition: 'https://schema.org/NewCondition'
      },
      aggregateRating: {
        '@type': 'AggregateRating',
        ratingValue: product.rating.toString(),
        reviewCount: product.reviewCount.toString()
      }
    };
    scriptTag.textContent = JSON.stringify(productSchema, null, 2);
  } else {
    const websiteSchema = {
      '@context': 'https://schema.org',
      '@type': 'WebSite',
      name: 'Ankush Picks',
      url: window.location.origin,
      description: description,
      potentialAction: {
        '@type': 'SearchAction',
        target: `${window.location.origin}/#search?q={search_term_string}`,
        'query-input': 'required name=search_term_string'
      }
    };
    scriptTag.textContent = JSON.stringify(websiteSchema, null, 2);
  }
}

export function generateSitemapXml(products: Product[]): string {
  const origin = window.location.origin;
  const urls = [
    { loc: `${origin}/`, priority: '1.0', changefreq: 'daily' },
    { loc: `${origin}/#categories`, priority: '0.8', changefreq: 'weekly' },
    { loc: `${origin}/#deals`, priority: '0.9', changefreq: 'daily' },
    { loc: `${origin}/#about`, priority: '0.5', changefreq: 'monthly' },
    { loc: `${origin}/#contact`, priority: '0.5', changefreq: 'monthly' },
    { loc: `${origin}/#disclosure`, priority: '0.6', changefreq: 'monthly' },
    ...products.map(p => ({
      loc: `${origin}/#product/${p.slug}`,
      priority: '0.8',
      changefreq: 'weekly'
    }))
  ];

  return `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls.map(u => `  <url>
    <loc>${u.loc}</loc>
    <changefreq>${u.changefreq}</changefreq>
    <priority>${u.priority}</priority>
  </url>`).join('\n')}
</urlset>`;
}

export const ROBOTS_TXT_CONTENT = `User-agent: *
Allow: /
Disallow: /#admin

Sitemap: /sitemap.xml
`;
