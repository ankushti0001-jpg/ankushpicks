import React, { useState, useEffect, useMemo } from 'react';
import { Category, FilterState, PageView, Product, SortOption } from './types';
import { storageService } from './services/storage';
import { updatePageSeo } from './utils/seo';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { FiltersBar } from './components/FiltersBar';
import { ProductCard } from './components/ProductCard';
import { HomeSections } from './components/HomeSections';
import { ProductDetailsModal } from './components/ProductDetailsModal';
import { AdminModal } from './components/AdminModal';
import { LegalPages } from './components/LegalPages';
import { CategoriesView } from './components/CategoriesView';
import { Footer } from './components/Footer';
import { SitemapModal } from './components/SitemapModal';
import { Flame, Sparkles, Search, Layers, SlidersHorizontal, RefreshCw } from 'lucide-react';

export default function App() {
  // Products and Categories data state
  const [products, setProducts] = useState<Product[]>(() => storageService.getProducts());
  const [categories, setCategories] = useState<Category[]>(() => storageService.getCategories());

  // Navigation and Modal states
  const [currentView, setCurrentView] = useState<PageView>('home');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [adminModalOpen, setAdminModalOpen] = useState(false);
  const [sitemapModalOpen, setSitemapModalOpen] = useState(false);
  const [isAdmin, setIsAdmin] = useState(() => storageService.isAdminLoggedIn());

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedSort, setSelectedSort] = useState<SortOption>('featured');
  const [minRating, setMinRating] = useState<number>(0);
  const [dealsOnly, setDealsOnly] = useState<boolean>(false);

  // Dark mode state
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    try {
      const stored = localStorage.getItem('ankushpicks_dark_mode');
      if (stored !== null) return stored === 'true';
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    } catch {
      return false;
    }
  });

  // Apply dark mode class to <html>
  useEffect(() => {
    try {
      if (darkMode) {
        document.documentElement.classList.add('dark');
        localStorage.setItem('ankushpicks_dark_mode', 'true');
      } else {
        document.documentElement.classList.remove('dark');
        localStorage.setItem('ankushpicks_dark_mode', 'false');
      }
    } catch (e) {
      console.error(e);
    }
  }, [darkMode]);

  // Listen for storage events (e.g., from admin actions)
  useEffect(() => {
    const handleProductsUpdated = (e: any) => {
      setProducts(e.detail || storageService.getProducts());
    };
    const handleCategoriesUpdated = (e: any) => {
      setCategories(e.detail || storageService.getCategories());
    };

    window.addEventListener('curatepicks:products-updated', handleProductsUpdated);
    window.addEventListener('curatepicks:categories-updated', handleCategoriesUpdated);
    return () => {
      window.removeEventListener('curatepicks:products-updated', handleProductsUpdated);
      window.removeEventListener('curatepicks:categories-updated', handleCategoriesUpdated);
    };
  }, []);

  // Hash-based routing for direct linkability & SEO
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#', '');
      if (!hash) {
        setCurrentView('home');
        return;
      }
      if (hash.startsWith('product/')) {
        const slug = hash.replace('product/', '');
        const found = products.find((p) => p.slug === slug || p.id === slug);
        if (found) {
          setSelectedProduct(found);
        }
      } else if (hash === 'categories') {
        setCurrentView('categories');
      } else if (hash === 'deals') {
        setCurrentView('deals');
        setDealsOnly(true);
      } else if (hash === 'about') {
        setCurrentView('about');
      } else if (hash === 'contact') {
        setCurrentView('contact');
      } else if (hash === 'disclosure') {
        setCurrentView('disclosure');
      } else if (hash === 'privacy') {
        setCurrentView('privacy');
      } else if (hash === 'terms') {
        setCurrentView('terms');
      } else if (hash === 'admin') {
        setAdminModalOpen(true);
      }
    };

    handleHashChange();
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, [products]);

  // Update dynamic SEO tags & Schema.org JSON-LD whenever view or product changes
  useEffect(() => {
    if (selectedProduct) {
      updatePageSeo(
        `${selectedProduct.name} - Review & Amazon Deal | Ankush Picks`,
        selectedProduct.shortDescription,
        selectedProduct
      );
    } else if (currentView === 'deals') {
      updatePageSeo(
        'Best Amazon Deals & Discounted Picks | Ankush Picks',
        'Explore verified price drops and exclusive discounts on editorially tested Amazon products.'
      );
    } else if (currentView === 'categories') {
      updatePageSeo(
        'Explore Amazon Product Categories | Ankush Picks',
        'Browse vetted recommendations across electronics, mobile accessories, computers, home, and fitness.'
      );
    } else if (currentView === 'about') {
      updatePageSeo(
        'About Ankush Picks - Independent Amazon Product Curation',
        'Discover our testing methodology, review standards, and commitment to honest recommendations.'
      );
    } else if (currentView === 'disclosure') {
      updatePageSeo(
        'Amazon Associates Affiliate Disclosure | Ankush Picks',
        'Official FTC compliance statement and Amazon Associates Operating Agreement disclosures.'
      );
    } else if (currentView === 'contact') {
      updatePageSeo(
        'Contact Our Editorial Team | Ankush Picks',
        'Get in touch with our product testing editors for inquiries, suggestions, or broken link reports.'
      );
    } else {
      updatePageSeo(
        'Ankush Picks - Honest Amazon Recommendations & Deals',
        'Discover curated Amazon product recommendations, verified price drops, and honest buyer reviews by Ankush.'
      );
    }
  }, [currentView, selectedProduct]);

  // Navigation handler
  const handleNavigate = (view: PageView, param?: string) => {
    setCurrentView(view);
    if (view === 'deals') {
      setDealsOnly(true);
      setSelectedCategory('');
      window.location.hash = 'deals';
    } else if (view === 'categories') {
      if (param) setSelectedCategory(param);
      window.location.hash = 'categories';
    } else if (view === 'home') {
      window.location.hash = '';
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      window.location.hash = view;
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleOpenProduct = (product: Product) => {
    setSelectedProduct(product);
    window.location.hash = `product/${product.slug}`;
  };

  const handleCloseProduct = () => {
    setSelectedProduct(null);
    if (window.location.hash.startsWith('#product/')) {
      window.history.pushState(null, '', window.location.pathname);
    }
  };

  const handleSelectCategoryFromPill = (catName: string) => {
    setSelectedCategory(catName);
    // If not on home or deals, switch to home with filter
    if (currentView !== 'home' && currentView !== 'deals') {
      setCurrentView('home');
    }
  };

  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('');
    setSelectedSort('featured');
    setMinRating(0);
    setDealsOnly(false);
  };

  const hasActiveFilters = Boolean(
    searchQuery || selectedCategory || minRating > 0 || dealsOnly || selectedSort !== 'featured'
  );

  // Filter and Sort Products
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      // Must be published for public view
      if (p.status !== 'published') return false;

      // Category filter
      if (selectedCategory && p.category !== selectedCategory) {
        return false;
      }

      // Deals only filter
      if (dealsOnly) {
        const hasDiscount = (p.discountPercentage && p.discountPercentage > 0) ||
          (p.originalPrice && p.originalPrice > p.price);
        if (!hasDiscount) return false;
      }

      // Rating filter
      if (minRating > 0 && p.rating < minRating) {
        return false;
      }

      // Search Query filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchName = p.name.toLowerCase().includes(q);
        const matchDesc = p.shortDescription.toLowerCase().includes(q) || (p.fullDescription && p.fullDescription.toLowerCase().includes(q));
        const matchCat = p.category.toLowerCase().includes(q);
        const matchAsin = p.asin ? p.asin.toLowerCase().includes(q) : false;
        if (!matchName && !matchDesc && !matchCat && !matchAsin) return false;
      }

      return true;
    }).sort((a, b) => {
      switch (selectedSort) {
        case 'price-asc':
          return a.price - b.price;
        case 'price-desc':
          return b.price - a.price;
        case 'rating-desc':
          return b.rating - a.rating || b.reviewCount - a.reviewCount;
        case 'discount-desc': {
          const discA = a.discountPercentage ?? 0;
          const discB = b.discountPercentage ?? 0;
          return discB - discA;
        }
        case 'newest':
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        case 'featured':
        default:
          if (a.isFeatured && !b.isFeatured) return -1;
          if (!a.isFeatured && b.isFeatured) return 1;
          return b.rating - a.rating;
      }
    });
  }, [products, selectedCategory, dealsOnly, minRating, searchQuery, selectedSort]);

  // Related products for current product view
  const relatedProducts = useMemo(() => {
    if (!selectedProduct) return [];
    return products
      .filter((p) => p.id !== selectedProduct.id && p.category === selectedProduct.category && p.status === 'published')
      .slice(0, 3);
  }, [products, selectedProduct]);

  // Refresh helper for admin edits
  const handleRefreshData = () => {
    setProducts(storageService.getProducts());
    setCategories(storageService.getCategories());
  };

  const isBrowsingFilteredOrDeals = hasActiveFilters || currentView === 'deals';

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 selection:bg-amber-100 selection:text-amber-900 dark:bg-slate-950 dark:text-slate-100 transition-colors">
      
      {/* Sticky Header */}
      <Header
        currentView={currentView}
        onNavigate={handleNavigate}
        searchQuery={searchQuery}
        onSearchChange={(q) => {
          setSearchQuery(q);
          if (currentView !== 'home') setCurrentView('home');
        }}
        categories={categories}
        selectedCategory={selectedCategory}
        onSelectCategory={handleSelectCategoryFromPill}
        isAdmin={isAdmin}
        onOpenAdmin={() => setAdminModalOpen(true)}
        darkMode={darkMode}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        
        {/* HOMEPAGE VIEW */}
        {currentView === 'home' && (
          <>
            {/* Show Hero only when not aggressively filtering */}
            {!hasActiveFilters && (
              <Hero
                searchQuery={searchQuery}
                onSearchChange={setSearchQuery}
                categories={categories}
                selectedCategory={selectedCategory}
                onSelectCategory={handleSelectCategoryFromPill}
                onBrowseDeals={() => handleNavigate('deals')}
                onViewAllProducts={() => {
                  const el = document.getElementById('catalog-grid');
                  el?.scrollIntoView({ behavior: 'smooth' });
                }}
              />
            )}

            <div id="catalog-grid" className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-8">
              
              {/* Filters bar */}
              <FiltersBar
                categories={categories}
                selectedCategory={selectedCategory}
                onSelectCategory={handleSelectCategoryFromPill}
                selectedSort={selectedSort}
                onSelectSort={setSelectedSort}
                minRating={minRating}
                onSelectMinRating={setMinRating}
                dealsOnly={dealsOnly}
                onToggleDealsOnly={() => setDealsOnly(!dealsOnly)}
                totalResults={filteredProducts.length}
                onResetFilters={handleResetFilters}
                hasActiveFilters={hasActiveFilters}
              />

              {/* Conditional Display: Categorized Home Sections VS Filtered Search Results */}
              {!isBrowsingFilteredOrDeals ? (
                /* Default Home Experience: Featured, Trending, Best Rated, Latest */
                <HomeSections
                  products={products}
                  onViewDetails={handleOpenProduct}
                  onCategoryClick={handleSelectCategoryFromPill}
                  onExploreMore={() => setSelectedSort('featured')}
                />
              ) : (
                /* Filtered Catalog Grid */
                <div>
                  <div className="mb-6 flex items-center justify-between">
                    <div>
                      <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
                        {dealsOnly && <Flame className="h-5 w-5 text-orange-500" />}
                        <span>
                          {selectedCategory ? `${selectedCategory} Recommendations` : dealsOnly ? "Today's Best Amazon Deals" : 'Search & Filter Results'}
                        </span>
                      </h2>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                        Showing {filteredProducts.length} curated products matching your criteria
                      </p>
                    </div>

                    {hasActiveFilters && (
                      <button
                        onClick={handleResetFilters}
                        className="text-xs font-bold text-amber-600 hover:underline dark:text-amber-400"
                      >
                        Reset all filters
                      </button>
                    )}
                  </div>

                  {filteredProducts.length > 0 ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                      {filteredProducts.map((product) => (
                        <ProductCard
                          key={product.id}
                          product={product}
                          onViewDetails={handleOpenProduct}
                          onCategoryClick={handleSelectCategoryFromPill}
                        />
                      ))}
                    </div>
                  ) : (
                    <div className="rounded-3xl border border-slate-200 bg-white p-12 text-center dark:border-slate-800 dark:bg-slate-900 shadow-sm my-8">
                      <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-amber-100 text-amber-600 dark:bg-amber-950 dark:text-amber-400 mb-4">
                        <Search className="h-7 w-7" />
                      </div>
                      <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                        No products match your criteria
                      </h3>
                      <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 max-w-md mx-auto mt-1 mb-6">
                        Try lowering your minimum rating or searching for broader terms like "headphone", "desk", or "charger".
                      </p>
                      <button
                        onClick={handleResetFilters}
                        className="rounded-xl bg-slate-900 px-5 py-2.5 text-xs font-bold text-white hover:bg-slate-800 dark:bg-amber-500 dark:text-slate-950 dark:hover:bg-amber-400"
                      >
                        Clear All Filters
                      </button>
                    </div>
                  )}
                </div>
              )}

            </div>
          </>
        )}

        {/* CATEGORIES DEPARTMENT VIEW */}
        {currentView === 'categories' && (
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <CategoriesView
              categories={categories}
              products={products}
              onSelectCategory={(catName) => {
                setSelectedCategory(catName);
                setCurrentView('home');
              }}
            />
          </div>
        )}

        {/* BEST DEALS VIEW */}
        {currentView === 'deals' && (
          <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-6">
            <div className="rounded-3xl bg-gradient-to-r from-orange-500 via-amber-500 to-amber-600 p-6 sm:p-10 text-white shadow-xl">
              <div className="inline-flex items-center gap-2 rounded-full bg-white/20 backdrop-blur-md px-3 py-1 text-xs font-bold mb-3">
                <Flame className="h-4 w-4 text-orange-200 fill-orange-200" />
                <span>Price Drops Verified Daily</span>
              </div>
              <h1 className="text-3xl sm:text-4xl font-black">
                Top Amazon Deals & Discounts
              </h1>
              <p className="text-xs sm:text-sm text-white/90 max-w-xl mt-2 leading-relaxed">
                Save up to 35% on top-rated tech, home essentials, and lifestyle products. We continuously check for price reductions against original Amazon list prices.
              </p>
            </div>

            <FiltersBar
              categories={categories}
              selectedCategory={selectedCategory}
              onSelectCategory={handleSelectCategoryFromPill}
              selectedSort={selectedSort}
              onSelectSort={setSelectedSort}
              minRating={minRating}
              onSelectMinRating={setMinRating}
              dealsOnly={dealsOnly}
              onToggleDealsOnly={() => setDealsOnly(!dealsOnly)}
              totalResults={filteredProducts.length}
              onResetFilters={handleResetFilters}
              hasActiveFilters={hasActiveFilters}
            />

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onViewDetails={handleOpenProduct}
                  onCategoryClick={handleSelectCategoryFromPill}
                />
              ))}
            </div>
          </div>
        )}

        {/* LEGAL & TRUST PAGES (Disclosure, About, Contact, Privacy, Terms) */}
        {(currentView === 'disclosure' ||
          currentView === 'about' ||
          currentView === 'contact' ||
          currentView === 'privacy' ||
          currentView === 'terms') && (
          <LegalPages
            view={currentView}
            onNavigateHome={() => handleNavigate('home')}
          />
        )}

      </main>

      {/* Product Details Full Modal / View */}
      {selectedProduct && (
        <ProductDetailsModal
          product={selectedProduct}
          onClose={handleCloseProduct}
          onSelectCategory={(cat) => {
            setSelectedCategory(cat);
            handleNavigate('home');
          }}
          relatedProducts={relatedProducts}
          onViewProduct={handleOpenProduct}
        />
      )}

      {/* Admin Dashboard Modal */}
      <AdminModal
        isOpen={adminModalOpen}
        onClose={() => setAdminModalOpen(false)}
        products={products}
        categories={categories}
        onRefreshData={handleRefreshData}
        isAdmin={isAdmin}
        onLoginSuccess={() => setIsAdmin(true)}
        onLogout={() => {
          storageService.logoutAdmin();
          setIsAdmin(false);
        }}
      />

      {/* SEO Sitemap & Robots Modal */}
      <SitemapModal
        isOpen={sitemapModalOpen}
        onClose={() => setSitemapModalOpen(false)}
        products={products}
      />

      {/* Footer */}
      <Footer
        onNavigate={handleNavigate}
        onOpenSitemapModal={() => setSitemapModalOpen(true)}
      />

    </div>
  );
}
