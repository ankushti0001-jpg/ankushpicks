import { Category, Product } from '../types';
import { INITIAL_CATEGORIES, INITIAL_PRODUCTS } from '../data/initialData';

const STORAGE_KEYS = {
  PRODUCTS: 'ankushpicks_products_v4',
  CATEGORIES: 'ankushpicks_categories_v4',
  ADMIN_TOKEN: 'ankushpicks_admin_session',
  DARK_MODE: 'ankushpicks_dark_mode'
};

export const storageService = {
  getProducts(): Product[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.warn('Failed to parse products from localStorage:', e);
    }
    // Default fallback
    this.saveProducts(INITIAL_PRODUCTS);
    return INITIAL_PRODUCTS;
  },

  saveProducts(products: Product[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
      // Broadcast change for multi-tab or reactive updates
      window.dispatchEvent(new CustomEvent('curatepicks:products-updated', { detail: products }));
    } catch (e) {
      console.error('Failed to save products to localStorage:', e);
    }
  },

  getProductById(id: string): Product | undefined {
    const products = this.getProducts();
    return products.find(p => p.id === id);
  },

  getProductBySlug(slug: string): Product | undefined {
    const products = this.getProducts();
    return products.find(p => p.slug === slug || p.id === slug);
  },

  addProduct(productData: Omit<Product, 'id' | 'createdAt' | 'updatedAt' | 'slug'> & { slug?: string }): Product {
    const products = this.getProducts();
    const id = 'prod-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7);
    const slug = productData.slug || productData.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '');
    const now = new Date().toISOString();

    const discountPercentage = productData.discountPercentage ?? (
      productData.originalPrice && productData.originalPrice > productData.price
        ? Math.round(((productData.originalPrice - productData.price) / productData.originalPrice) * 100)
        : undefined
    );

    const newProduct: Product = {
      ...productData,
      id,
      slug: `${slug}-${id.substring(5, 9)}`,
      discountPercentage,
      createdAt: now,
      updatedAt: now
    };

    const updated = [newProduct, ...products];
    this.saveProducts(updated);
    return newProduct;
  },

  updateProduct(id: string, updates: Partial<Product>): Product | null {
    const products = this.getProducts();
    const index = products.findIndex(p => p.id === id);
    if (index === -1) return null;

    const existing = products[index];
    const updatedPrice = updates.price !== undefined ? updates.price : existing.price;
    const updatedOriginal = updates.originalPrice !== undefined ? updates.originalPrice : existing.originalPrice;

    let discountPercentage = updates.discountPercentage;
    if (discountPercentage === undefined) {
      if (updatedOriginal && updatedOriginal > updatedPrice) {
        discountPercentage = Math.round(((updatedOriginal - updatedPrice) / updatedOriginal) * 100);
      } else {
        discountPercentage = undefined;
      }
    }

    const updatedProduct: Product = {
      ...existing,
      ...updates,
      price: updatedPrice,
      originalPrice: updatedOriginal,
      discountPercentage,
      updatedAt: new Date().toISOString()
    };

    products[index] = updatedProduct;
    this.saveProducts(products);
    return updatedProduct;
  },

  deleteProduct(id: string): boolean {
    const products = this.getProducts();
    const filtered = products.filter(p => p.id !== id);
    if (filtered.length !== products.length) {
      this.saveProducts(filtered);
      return true;
    }
    return false;
  },

  getCategories(): Category[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.warn('Failed to parse categories from localStorage:', e);
    }
    this.saveCategories(INITIAL_CATEGORIES);
    return INITIAL_CATEGORIES;
  },

  saveCategories(categories: Category[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(categories));
      window.dispatchEvent(new CustomEvent('curatepicks:categories-updated', { detail: categories }));
    } catch (e) {
      console.error('Failed to save categories to localStorage:', e);
    }
  },

  addCategory(name: string, description?: string): Category {
    const categories = this.getCategories();
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '');
    const id = 'cat-' + Date.now();
    const newCat: Category = { id, name, slug, description };
    const updated = [...categories, newCat];
    this.saveCategories(updated);
    return newCat;
  },

  deleteCategory(id: string): boolean {
    const categories = this.getCategories();
    const filtered = categories.filter(c => c.id !== id);
    if (filtered.length !== categories.length) {
      this.saveCategories(filtered);
      return true;
    }
    return false;
  },

  resetDefaults(): void {
    this.saveProducts(INITIAL_PRODUCTS);
    this.saveCategories(INITIAL_CATEGORIES);
  },

  // Admin authentication (simulated securely with session token)
  isAdminLoggedIn(): boolean {
    return !!sessionStorage.getItem(STORAGE_KEYS.ADMIN_TOKEN) || !!localStorage.getItem(STORAGE_KEYS.ADMIN_TOKEN);
  },

  loginAdmin(passcode: string): boolean {
    // Default master admin passcode is 'admin123' or 'curate2026'
    if (passcode.trim() === 'admin123' || passcode.trim() === 'curate2026' || passcode.trim() === 'admin') {
      const token = 'auth_' + Math.random().toString(36).substring(2) + '_' + Date.now();
      sessionStorage.setItem(STORAGE_KEYS.ADMIN_TOKEN, token);
      localStorage.setItem(STORAGE_KEYS.ADMIN_TOKEN, token);
      return true;
    }
    return false;
  },

  logoutAdmin(): void {
    sessionStorage.removeItem(STORAGE_KEYS.ADMIN_TOKEN);
    localStorage.removeItem(STORAGE_KEYS.ADMIN_TOKEN);
  }
};
