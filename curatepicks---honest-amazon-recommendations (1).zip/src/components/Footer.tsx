import React, { useState } from 'react';
import { PageView } from '../types';
import { Sparkles, ShieldCheck, Mail, Check, ExternalLink, Flame, FileCode } from 'lucide-react';

interface FooterProps {
  onNavigate: (view: PageView) => void;
  onOpenSitemapModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, onOpenSitemapModal }) => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setEmail('');
      setTimeout(() => setSubscribed(false), 5000);
    }
  };

  return (
    <footer className="mt-20 border-t border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-950 transition-colors">
      
      {/* Top Affiliate Disclosure Bar (FTC Mandatory) */}
      <div className="border-b border-slate-200/80 bg-amber-500/10 px-4 py-4 text-center dark:border-slate-800 dark:bg-amber-950/20">
        <div className="mx-auto max-w-4xl text-xs leading-relaxed text-amber-950 dark:text-amber-300">
          <div className="flex items-center justify-center gap-1.5 font-bold mb-1">
            <ShieldCheck className="h-4 w-4 text-amber-600 dark:text-amber-400" />
            <span>Official Amazon Associates Affiliate Disclosure</span>
          </div>
          <p className="max-w-3xl mx-auto">
            Ankush Picks is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to Amazon.com. As an Amazon Associate, we earn from qualifying purchases at no additional cost to you. Product prices and availability are accurate as of the date/time indicated and are subject to change.
          </p>
        </div>
      </div>

      {/* Main Footer Links & Newsletter */}
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-4 lg:grid-cols-5">
          
          {/* Brand Column */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-tr from-amber-500 to-orange-500 text-white shadow-md">
                <Sparkles className="h-4 w-4" />
              </div>
              <span className="text-xl font-extrabold tracking-tight text-slate-900 dark:text-white">
                Ankush <span className="text-amber-600 dark:text-amber-400">Picks</span>
              </span>
            </div>

            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 max-w-sm leading-relaxed">
              Honest, research-backed product recommendations and verified price drops on Amazon. We never let sponsors dictate our ratings.
            </p>

            <div className="pt-2">
              <p className="text-xs font-bold text-slate-900 dark:text-white mb-2">
                Weekly Deal Alerts & Hand-Picked Steals
              </p>
              {subscribed ? (
                <div className="flex items-center gap-2 text-xs font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/50 p-2.5 rounded-xl border border-emerald-200 dark:border-emerald-800">
                  <Check className="h-4 w-4" />
                  <span>You're subscribed! We only send verified deal drops.</span>
                </div>
              ) : (
                <form onSubmit={handleSubscribe} className="flex gap-2 max-w-sm">
                  <input
                    type="email"
                    required
                    placeholder="Enter your email..."
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="flex-1 rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs text-slate-900 placeholder-slate-400 focus:border-amber-500 focus:outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-white"
                  />
                  <button
                    type="submit"
                    className="rounded-xl bg-slate-900 px-3.5 py-2 text-xs font-bold text-white hover:bg-slate-800 dark:bg-amber-500 dark:text-slate-950 dark:hover:bg-amber-400 shrink-0"
                  >
                    Subscribe
                  </button>
                </form>
              )}
            </div>
          </div>

          {/* Quick Nav */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-white mb-3">
              Explore
            </h3>
            <ul className="space-y-2 text-xs text-slate-600 dark:text-slate-400 font-medium">
              <li>
                <button onClick={() => onNavigate('home')} className="hover:text-amber-600 dark:hover:text-amber-400">
                  Home Catalog
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('categories')} className="hover:text-amber-600 dark:hover:text-amber-400">
                  All Categories
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('deals')} className="hover:text-amber-600 dark:hover:text-amber-400 flex items-center gap-1">
                  <span>Best Deals</span>
                  <span className="rounded bg-orange-100 px-1 py-0.2 text-[9px] font-bold text-orange-700 dark:bg-orange-950 dark:text-orange-300">Hot</span>
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('about')} className="hover:text-amber-600 dark:hover:text-amber-400">
                  Testing Methodology
                </button>
              </li>
            </ul>
          </div>

          {/* Legal / Compliance */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-white mb-3">
              Trust & Legal
            </h3>
            <ul className="space-y-2 text-xs text-slate-600 dark:text-slate-400 font-medium">
              <li>
                <button onClick={() => onNavigate('disclosure')} className="hover:text-amber-600 dark:hover:text-amber-400">
                  Affiliate Disclosure
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('privacy')} className="hover:text-amber-600 dark:hover:text-amber-400">
                  Privacy Policy
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('terms')} className="hover:text-amber-600 dark:hover:text-amber-400">
                  Terms of Service
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('contact')} className="hover:text-amber-600 dark:hover:text-amber-400">
                  Contact Us
                </button>
              </li>
            </ul>
          </div>

          {/* SEO & Indexing Tools */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-white mb-3">
              SEO & Indexing
            </h3>
            <ul className="space-y-2 text-xs text-slate-600 dark:text-slate-400 font-medium">
              <li>
                <button
                  onClick={onOpenSitemapModal}
                  className="flex items-center gap-1.5 hover:text-amber-600 dark:hover:text-amber-400"
                >
                  <FileCode className="h-3.5 w-3.5 text-slate-400" />
                  <span>Sitemap.xml</span>
                </button>
              </li>
              <li>
                <a
                  href="/robots.txt"
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-1.5 hover:text-amber-600 dark:hover:text-amber-400"
                >
                  <FileCode className="h-3.5 w-3.5 text-slate-400" />
                  <span>Robots.txt</span>
                </a>
              </li>
              <li>
                <span className="text-[11px] text-slate-400">
                  Schema.org JSON-LD active
                </span>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom copyright */}
        <div className="mt-12 border-t border-slate-100 pt-6 dark:border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <p>© {new Date().getFullYear()} Ankush Picks. All rights reserved.</p>
          <p className="text-[11px]">
            Designed for high conversion, FTC compliance, and genuine buyer trust.
          </p>
        </div>
      </div>
    </footer>
  );
};
