import React, { useState } from 'react';
import {
  Search,
  Menu,
  X,
  Sparkles,
  ShieldCheck,
  Tag,
  SlidersHorizontal,
  Lock,
  Sun,
  Moon,
  ExternalLink,
  ChevronRight,
  Flame
} from 'lucide-react';
import { Category, PageView } from '../types';

interface HeaderProps {
  currentView: PageView;
  onNavigate: (view: PageView, param?: string) => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  categories: Category[];
  selectedCategory: string;
  onSelectCategory: (cat: string) => void;
  isAdmin: boolean;
  onOpenAdmin: () => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentView,
  onNavigate,
  searchQuery,
  onSearchChange,
  categories,
  selectedCategory,
  onSelectCategory,
  isAdmin,
  onOpenAdmin,
  darkMode,
  onToggleDarkMode
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchFocused, setSearchFocused] = useState(false);

  const handleNavClick = (view: PageView) => {
    onNavigate(view);
    setMobileMenuOpen(false);
  };

  const handleCategoryClick = (catName: string) => {
    onSelectCategory(catName);
    onNavigate('categories');
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200/80 bg-white/95 backdrop-blur-md transition-colors dark:border-slate-800 dark:bg-slate-900/95">
      {/* Top Banner - Disclosure & Trust Badge */}
      <div className="bg-slate-900 px-4 py-1 text-center text-xs font-medium text-slate-300 dark:bg-black">
        <div className="mx-auto flex max-w-7xl items-center justify-between">
          <div className="hidden sm:flex items-center gap-2">
            <span className="inline-block h-1.5 w-1.5 rounded-full bg-emerald-400"></span>
            <span>Independent Editorial Reviews • Updated Daily</span>
          </div>
          <div className="mx-auto sm:mx-0 flex items-center gap-1.5 text-slate-300">
            <span className="font-semibold text-amber-400">FTC Notice:</span>
            <span>Amazon Associate participant. We earn from qualifying purchases.</span>
            <button
              onClick={() => onNavigate('disclosure')}
              className="ml-1 text-amber-300 underline hover:text-white"
            >
              Learn more
            </button>
          </div>
          <div className="hidden md:flex items-center gap-3">
            <span className="text-slate-400">Amazon Associates ID Verified</span>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between gap-4">
          
          {/* Logo / Brand */}
          <div className="flex items-center gap-6">
            <button
              onClick={() => handleNavClick('home')}
              className="flex items-center gap-2.5 text-left group"
            >
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-tr from-amber-500 via-amber-600 to-orange-500 text-white shadow-md shadow-amber-500/20 group-hover:scale-105 transition-transform">
                <Sparkles className="h-5 w-5" />
              </div>
              <div>
                <span className="text-xl font-extrabold tracking-tight text-slate-900 dark:text-white flex items-center gap-1">
                  Ankush <span className="text-amber-600 dark:text-amber-400">Picks</span>
                </span>
                <span className="hidden sm:block text-[10px] uppercase tracking-wider font-semibold text-slate-400 dark:text-slate-500 -mt-1">
                  Amazon Recommendations
                </span>
              </div>
            </button>

            {/* Desktop Navigation Links */}
            <nav className="hidden lg:flex items-center gap-1">
              <button
                onClick={() => handleNavClick('home')}
                className={`rounded-lg px-3 py-1.5 text-sm font-semibold transition-colors ${
                  currentView === 'home' && !selectedCategory
                    ? 'bg-slate-100 text-slate-900 dark:bg-slate-800 dark:text-white'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800'
                }`}
              >
                Home
              </button>

              <button
                onClick={() => handleNavClick('categories')}
                className={`rounded-lg px-3 py-1.5 text-sm font-semibold transition-colors ${
                  currentView === 'categories'
                    ? 'bg-slate-100 text-slate-900 dark:bg-slate-800 dark:text-white'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800'
                }`}
              >
                Categories
              </button>

              <button
                onClick={() => handleNavClick('deals')}
                className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm font-semibold transition-colors ${
                  currentView === 'deals'
                    ? 'bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800'
                }`}
              >
                <Flame className="h-4 w-4 text-orange-500" />
                <span>Best Deals</span>
              </button>

              <button
                onClick={() => handleNavClick('about')}
                className={`rounded-lg px-3 py-1.5 text-sm font-semibold transition-colors ${
                  currentView === 'about'
                    ? 'bg-slate-100 text-slate-900 dark:bg-slate-800 dark:text-white'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800'
                }`}
              >
                About
              </button>

              <button
                onClick={() => handleNavClick('contact')}
                className={`rounded-lg px-3 py-1.5 text-sm font-semibold transition-colors ${
                  currentView === 'contact'
                    ? 'bg-slate-100 text-slate-900 dark:bg-slate-800 dark:text-white'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800'
                }`}
              >
                Contact
              </button>
            </nav>
          </div>

          {/* Search Bar */}
          <div className="flex-1 max-w-md mx-2 sm:mx-4">
            <div
              className={`relative flex items-center rounded-xl border bg-slate-50 transition-all dark:bg-slate-800/80 ${
                searchFocused
                  ? 'border-amber-500 ring-2 ring-amber-500/20 bg-white dark:bg-slate-800'
                  : 'border-slate-200 dark:border-slate-700'
              }`}
            >
              <Search className="ml-3 h-4 w-4 text-slate-400 dark:text-slate-500 shrink-0" />
              <input
                type="text"
                placeholder="Search vetted Amazon products, brands, ASIN..."
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                onFocus={() => setSearchFocused(true)}
                onBlur={() => setSearchFocused(false)}
                className="w-full bg-transparent px-3 py-2 text-sm text-slate-900 placeholder-slate-400 focus:outline-none dark:text-white dark:placeholder-slate-500"
              />
              {searchQuery && (
                <button
                  onClick={() => onSearchChange('')}
                  className="mr-2.5 rounded-full p-1 text-slate-400 hover:bg-slate-200 hover:text-slate-600 dark:hover:bg-slate-700"
                  title="Clear search"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Actions & Controls */}
          <div className="flex items-center gap-2">
            {/* Dark mode toggle */}
            <button
              onClick={onToggleDarkMode}
              className="rounded-lg p-2 text-slate-500 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-white transition-colors"
              title={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
              aria-label="Toggle dark mode"
            >
              {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </button>

            {/* Admin Management Button */}
            <button
              onClick={onOpenAdmin}
              className={`flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-semibold shadow-sm transition-all ${
                isAdmin
                  ? 'border-emerald-300 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 dark:border-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300'
                  : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              <Lock className={`h-3.5 w-3.5 ${isAdmin ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400'}`} />
              <span className="hidden sm:inline">{isAdmin ? 'Admin Dashboard' : 'Admin'}</span>
            </button>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden rounded-lg p-2 text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
              aria-label="Open navigation menu"
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-6 dark:border-slate-800 dark:bg-slate-900">
          <div className="space-y-1">
            <button
              onClick={() => handleNavClick('home')}
              className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <span>Home</span>
              <ChevronRight className="h-4 w-4 text-slate-400" />
            </button>

            <button
              onClick={() => handleNavClick('categories')}
              className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <span>Categories</span>
              <ChevronRight className="h-4 w-4 text-slate-400" />
            </button>

            <button
              onClick={() => handleNavClick('deals')}
              className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-sm font-semibold text-amber-600 hover:bg-amber-50 dark:text-amber-400 dark:hover:bg-amber-950/40"
            >
              <div className="flex items-center gap-2">
                <Flame className="h-4 w-4 text-orange-500" />
                <span>Best Deals & Discounts</span>
              </div>
              <ChevronRight className="h-4 w-4 text-amber-400" />
            </button>

            <button
              onClick={() => handleNavClick('about')}
              className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <span>About Ankush Picks</span>
              <ChevronRight className="h-4 w-4 text-slate-400" />
            </button>

            <button
              onClick={() => handleNavClick('contact')}
              className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <span>Contact Us</span>
              <ChevronRight className="h-4 w-4 text-slate-400" />
            </button>

            <button
              onClick={() => handleNavClick('disclosure')}
              className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-sm font-semibold text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
            >
              <span>Amazon Affiliate Disclosure</span>
              <ChevronRight className="h-4 w-4 text-slate-400" />
            </button>
          </div>

          {/* Quick Category Pills */}
          <div className="mt-4 border-t border-slate-100 pt-3 dark:border-slate-800">
            <p className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Popular Categories</p>
            <div className="flex flex-wrap gap-1.5">
              {categories.map((c) => (
                <button
                  key={c.id}
                  onClick={() => handleCategoryClick(c.name)}
                  className={`rounded-full px-2.5 py-1 text-xs font-medium transition-colors ${
                    selectedCategory === c.name
                      ? 'bg-amber-500 text-white'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300'
                  }`}
                >
                  {c.name}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
