import React, { useState } from 'react';
import { X, Copy, Check, Download, FileCode } from 'lucide-react';
import { Product } from '../types';
import { generateSitemapXml, ROBOTS_TXT_CONTENT } from '../utils/seo';

interface SitemapModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
}

export const SitemapModal: React.FC<SitemapModalProps> = ({ isOpen, onClose, products }) => {
  const [activeTab, setActiveTab] = useState<'sitemap' | 'robots'>('sitemap');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const sitemapXml = generateSitemapXml(products);
  const currentContent = activeTab === 'sitemap' ? sitemapXml : ROBOTS_TXT_CONTENT;

  const handleCopy = () => {
    navigator.clipboard.writeText(currentContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const filename = activeTab === 'sitemap' ? 'sitemap.xml' : 'robots.txt';
    const type = activeTab === 'sitemap' ? 'application/xml' : 'text/plain';
    const blob = new Blob([currentContent], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm">
      <div className="w-full max-w-3xl rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <FileCode className="h-5 w-5 text-amber-500" />
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Search Engine Optimization Files
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Generated XML Sitemap & Robots.txt for crawler indexing
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="rounded-full p-1.5 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Tab switch */}
        <div className="flex items-center justify-between border-b border-slate-200 px-6 pt-3 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40">
          <div className="flex gap-2">
            <button
              onClick={() => setActiveTab('sitemap')}
              className={`border-b-2 px-3 py-2 text-xs font-bold transition-colors ${
                activeTab === 'sitemap'
                  ? 'border-amber-500 text-amber-600 dark:text-amber-400'
                  : 'border-transparent text-slate-500 hover:text-slate-900 dark:text-slate-400'
              }`}
            >
              sitemap.xml ({products.length + 6} URLs)
            </button>
            <button
              onClick={() => setActiveTab('robots')}
              className={`border-b-2 px-3 py-2 text-xs font-bold transition-colors ${
                activeTab === 'robots'
                  ? 'border-amber-500 text-amber-600 dark:text-amber-400'
                  : 'border-transparent text-slate-500 hover:text-slate-900 dark:text-slate-400'
              }`}
            >
              robots.txt
            </button>
          </div>

          <div className="flex items-center gap-2 pb-2">
            <button
              onClick={handleCopy}
              className="flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-2.5 py-1 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
            >
              {copied ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
              <span>{copied ? 'Copied' : 'Copy'}</span>
            </button>
            <button
              onClick={handleDownload}
              className="flex items-center gap-1 rounded-lg bg-amber-500 px-2.5 py-1 text-xs font-bold text-white hover:bg-amber-600"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Download</span>
            </button>
          </div>
        </div>

        {/* Content view */}
        <div className="flex-1 overflow-y-auto p-4 bg-slate-950 font-mono text-xs text-emerald-400">
          <pre className="whitespace-pre-wrap">{currentContent}</pre>
        </div>
      </div>
    </div>
  );
};
