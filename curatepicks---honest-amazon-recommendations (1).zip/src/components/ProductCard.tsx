import React, { useState } from 'react';
import { Star, ExternalLink, Eye, Flame, ShoppingBag, ShieldCheck, Tag } from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onViewDetails: (product: Product) => void;
  onCategoryClick?: (category: string) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onViewDetails,
  onCategoryClick
}) => {
  const [imgError, setImgError] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);

  // Fallback image generator or placeholder
  const fallbackImg = `https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80`;

  const discountVal = product.discountPercentage ?? (
    product.originalPrice && product.originalPrice > product.price
      ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
      : null
  );

  const formatPrice = (val: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(val);
  };

  const renderStars = (rating: number) => {
    return (
      <div className="flex items-center gap-0.5 text-amber-500">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`h-3.5 w-3.5 ${
              star <= Math.round(rating)
                ? 'fill-amber-400 text-amber-400'
                : 'text-slate-300 dark:text-slate-600'
            }`}
          />
        ))}
      </div>
    );
  };

  return (
    <div className="group relative flex flex-col justify-between overflow-hidden rounded-2xl border border-slate-200/90 bg-white shadow-sm transition-all duration-300 hover:-translate-y-1 hover:border-amber-400/80 hover:shadow-xl hover:shadow-amber-500/10 dark:border-slate-800 dark:bg-slate-900 dark:hover:border-amber-500/60">
      
      {/* Top Media Header */}
      <div>
        <div className="relative aspect-[4/3] w-full overflow-hidden bg-slate-100 dark:bg-slate-800">
          
          {/* Badge overlays */}
          <div className="absolute top-3 left-3 z-10 flex flex-col gap-1.5 items-start">
            {product.badge && (
              <span className="inline-flex items-center gap-1 rounded-full bg-slate-900/90 px-2.5 py-0.5 text-[11px] font-bold tracking-wide text-white backdrop-blur-md shadow-sm dark:bg-amber-400 dark:text-slate-950">
                <Flame className="h-3 w-3 text-amber-400 dark:text-slate-950" />
                {product.badge}
              </span>
            )}
            {discountVal && discountVal > 0 ? (
              <span className="inline-flex items-center rounded-full bg-rose-600 px-2.5 py-0.5 text-[11px] font-bold text-white shadow-sm">
                Save {discountVal}%
              </span>
            ) : null}
          </div>

          {/* Category Chip */}
          <div className="absolute top-3 right-3 z-10">
            <button
              onClick={(e) => {
                e.stopPropagation();
                if (onCategoryClick) onCategoryClick(product.category);
              }}
              className="rounded-full bg-white/90 px-2.5 py-1 text-[11px] font-semibold text-slate-700 shadow-sm backdrop-blur-md hover:bg-white hover:text-slate-900 dark:bg-slate-900/90 dark:text-slate-300 dark:hover:bg-slate-800"
            >
              {product.category}
            </button>
          </div>

          {/* Product Image with smooth load */}
          <img
            src={imgError ? fallbackImg : product.imageUrl}
            alt={product.name}
            onError={() => setImgError(true)}
            onLoad={() => setImageLoaded(true)}
            className={`h-full w-full object-contain p-4 transition-transform duration-500 group-hover:scale-105 ${
              imageLoaded ? 'opacity-100' : 'opacity-0'
            }`}
          />

          {!imageLoaded && (
            <div className="absolute inset-0 flex items-center justify-center bg-slate-100 dark:bg-slate-800">
              <div className="h-6 w-6 animate-spin rounded-full border-2 border-amber-500 border-t-transparent"></div>
            </div>
          )}

          {/* Quick View Button overlay on hover */}
          <div className="absolute inset-0 flex items-center justify-center bg-slate-900/30 opacity-0 backdrop-blur-[2px] transition-opacity duration-200 group-hover:opacity-100">
            <button
              onClick={() => onViewDetails(product)}
              className="flex items-center gap-1.5 rounded-xl bg-white px-4 py-2 text-xs font-bold text-slate-900 shadow-lg hover:bg-slate-50 transition-transform active:scale-95"
            >
              <Eye className="h-4 w-4 text-amber-600" />
              Quick Specs
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-5">
          {/* Rating & Reviews */}
          <div className="flex items-center justify-between gap-2 mb-2">
            <div className="flex items-center gap-1.5">
              {renderStars(product.rating)}
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                {product.rating.toFixed(1)}
              </span>
            </div>
            {product.reviewCount > 0 && (
              <span className="text-xs text-slate-500 dark:text-slate-400">
                ({product.reviewCount.toLocaleString()} reviews)
              </span>
            )}
          </div>

          {/* Product Title */}
          <h3
            onClick={() => onViewDetails(product)}
            className="cursor-pointer text-sm sm:text-base font-bold text-slate-900 line-clamp-2 hover:text-amber-600 transition-colors dark:text-white dark:hover:text-amber-400 leading-snug"
            title={product.name}
          >
            {product.name}
          </h3>

          {/* Short Description */}
          <p className="mt-1.5 text-xs text-slate-600 dark:text-slate-400 line-clamp-2 leading-relaxed">
            {product.shortDescription}
          </p>

          {/* Price Area */}
          <div className="mt-4 flex items-baseline gap-2">
            <span className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
              {formatPrice(product.price)}
            </span>
            {product.originalPrice && product.originalPrice > product.price && (
              <span className="text-xs sm:text-sm text-slate-400 line-through">
                {formatPrice(product.originalPrice)}
              </span>
            )}
          </div>

          <p className="mt-0.5 text-[11px] text-slate-400 dark:text-slate-500">
            Price & availability may change on Amazon
          </p>
        </div>
      </div>

      {/* Footer Action Buttons */}
      <div className="border-t border-slate-100 bg-slate-50/50 p-4 pt-3 dark:border-slate-800 dark:bg-slate-900/60">
        <div className="flex items-center gap-2">
          {/* View Details secondary */}
          <button
            onClick={() => onViewDetails(product)}
            className="flex-1 rounded-xl border border-slate-300 bg-white py-2.5 text-xs font-bold text-slate-700 hover:bg-slate-100 transition-colors dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700"
          >
            Details
          </button>

          {/* Buy on Amazon Primary Affiliate CTA */}
          <a
            href={product.affiliateUrl}
            target="_blank"
            rel="noopener noreferrer sponsored"
            className="flex-[2] flex items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-600 to-orange-500 py-2.5 px-3 text-xs font-extrabold text-white shadow-md shadow-amber-500/20 hover:from-amber-600 hover:to-orange-600 hover:shadow-lg active:scale-95 transition-all text-center"
            title={`Buy ${product.name} on Amazon`}
          >
            <ShoppingBag className="h-3.5 w-3.5 shrink-0" />
            <span className="truncate">Buy on Amazon</span>
            <ExternalLink className="h-3 w-3 shrink-0 opacity-80" />
          </a>
        </div>
      </div>
    </div>
  );
};
