import React from 'react';
import { Category, Product } from '../types';
import {
  Tv,
  Smartphone,
  Laptop,
  Coffee,
  Sparkles,
  Watch,
  Dumbbell,
  Briefcase,
  Gamepad2,
  Compass,
  ArrowRight,
  Layers
} from 'lucide-react';

interface CategoriesViewProps {
  categories: Category[];
  products: Product[];
  onSelectCategory: (categoryName: string) => void;
}

const ICON_MAP: Record<string, React.ReactNode> = {
  Tv: <Tv className="h-6 w-6" />,
  Smartphone: <Smartphone className="h-6 w-6" />,
  Laptop: <Laptop className="h-6 w-6" />,
  Coffee: <Coffee className="h-6 w-6" />,
  Sparkles: <Sparkles className="h-6 w-6" />,
  Watch: <Watch className="h-6 w-6" />,
  Dumbbell: <Dumbbell className="h-6 w-6" />,
  Briefcase: <Briefcase className="h-6 w-6" />,
  Gamepad2: <Gamepad2 className="h-6 w-6" />,
  Compass: <Compass className="h-6 w-6" />
};

export const CategoriesView: React.FC<CategoriesViewProps> = ({
  categories,
  products,
  onSelectCategory
}) => {
  return (
    <div className="py-8 space-y-8">
      <div>
        <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400 text-xs font-bold uppercase tracking-wider mb-1">
          <Layers className="h-4 w-4" />
          <span>Curated Departments</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-black text-slate-900 dark:text-white">
          Browse by Category
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-xl">
          Explore expertly vetted products across technology, everyday ergonomics, home barista gear, fitness, and more.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {categories.map((cat) => {
          const categoryProducts = products.filter((p) => p.category === cat.name && p.status === 'published');
          const count = categoryProducts.length;
          const icon = cat.iconName ? ICON_MAP[cat.iconName] || <Compass className="h-6 w-6" /> : <Compass className="h-6 w-6" />;

          return (
            <div
              key={cat.id}
              onClick={() => onSelectCategory(cat.name)}
              className="group cursor-pointer rounded-3xl border border-slate-200/90 bg-white p-6 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:border-amber-400/80 hover:shadow-xl dark:border-slate-800 dark:bg-slate-900 dark:hover:border-amber-500/50 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-100 text-amber-600 transition-colors group-hover:bg-amber-500 group-hover:text-white dark:bg-amber-950/60 dark:text-amber-400">
                    {icon}
                  </div>
                  <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-bold text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                    {count} {count === 1 ? 'item' : 'items'}
                  </span>
                </div>

                <h3 className="text-lg font-bold text-slate-900 group-hover:text-amber-600 dark:text-white dark:group-hover:text-amber-400 transition-colors">
                  {cat.name}
                </h3>

                <p className="mt-2 text-xs text-slate-500 dark:text-slate-400 line-clamp-2 leading-relaxed">
                  {cat.description || `Handpicked best-rated products in ${cat.name}.`}
                </p>
              </div>

              {/* Sample preview images */}
              <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <div className="flex -space-x-2">
                  {categoryProducts.slice(0, 3).map((p, idx) => (
                    <img
                      key={p.id}
                      src={p.imageUrl}
                      alt=""
                      className="h-8 w-8 rounded-full border-2 border-white object-contain bg-slate-50 dark:border-slate-900 dark:bg-slate-800"
                    />
                  ))}
                  {count > 3 && (
                    <div className="flex h-8 w-8 items-center justify-center rounded-full border-2 border-white bg-slate-200 text-[10px] font-bold text-slate-700 dark:border-slate-900 dark:bg-slate-700 dark:text-slate-200">
                      +{count - 3}
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-1 text-xs font-bold text-amber-600 dark:text-amber-400 group-hover:translate-x-0.5 transition-transform">
                  <span>Explore</span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
