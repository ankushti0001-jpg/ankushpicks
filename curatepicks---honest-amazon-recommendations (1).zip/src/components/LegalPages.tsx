import React, { useState } from 'react';
import { PageView } from '../types';
import { ShieldCheck, Mail, Send, CheckCircle2, AlertCircle, Sparkles, Scale, FileText, Info } from 'lucide-react';

interface LegalPagesProps {
  view: PageView;
  onNavigateHome: () => void;
}

export const LegalPages: React.FC<LegalPagesProps> = ({ view, onNavigateHome }) => {
  // Contact form state
  const [contactSubmitted, setContactSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: 'Product Question / Suggestion',
    message: ''
  });

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setContactSubmitted(true);
  };

  return (
    <div className="py-12 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
      
      {/* 1. Affiliate Disclosure */}
      {view === 'disclosure' && (
        <article className="prose prose-slate dark:prose-invert max-w-none space-y-6">
          <div className="border-b border-slate-200 pb-6 dark:border-slate-800">
            <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400 text-xs font-bold uppercase tracking-wider mb-2">
              <ShieldCheck className="h-4 w-4" />
              <span>Full FTC & Amazon Associates Compliance</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-black text-slate-900 dark:text-white">
              Amazon Affiliate Disclosure
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">
              Last updated: October 2026 • Effective Date: January 1, 2026
            </p>
          </div>

          {/* Official Amazon Statement Box */}
          <div className="rounded-2xl border-2 border-amber-300 bg-amber-50/80 p-6 dark:border-amber-700/60 dark:bg-amber-950/40">
            <h2 className="text-base font-bold text-amber-900 dark:text-amber-200">
              Mandatory Amazon Associates Operating Statement:
            </h2>
            <p className="mt-2 text-sm sm:text-base font-semibold text-amber-950 dark:text-amber-100">
              "Ankush Picks is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to Amazon.com and affiliated sites."
            </p>
          </div>

          <div className="space-y-4 text-sm sm:text-base text-slate-700 dark:text-slate-300 leading-relaxed">
            <h3 className="text-xl font-bold text-slate-900 dark:text-white mt-6">
              How Our Affiliate Links Work
            </h3>
            <p>
              When you click on the "Buy on Amazon" buttons or product recommendation links on Ankush Picks, you are directed directly to Amazon's official retail platform. If you decide to make a purchase, Amazon may award us a small referral commission.
            </p>
            <p>
              <strong>Crucially, this comes at zero additional cost to you.</strong> You pay the exact same price as any other customer shopping on Amazon, and you remain eligible for all standard Amazon discounts, Prime shipping perks, and customer service.
            </p>

            <h3 className="text-xl font-bold text-slate-900 dark:text-white mt-6">
              Our Editorial Integrity
            </h3>
            <p>
              Our recommendations are chosen strictly based on product performance, customer feedback, verified user reviews, build quality, and value for money. We do not accept sponsored placements that compromise our honest assessment. If a product fails to meet high durability and usability standards, it is never recommended.
            </p>

            <h3 className="text-xl font-bold text-slate-900 dark:text-white mt-6">
              Price & Availability Fluctuations
            </h3>
            <p>
              Amazon prices and stock availability fluctuate dynamically due to seller promotions and demand. While we strive to present accurate pricing data, the official price displayed on Amazon.com at the time of your purchase will always supersede the estimates on our site.
            </p>
          </div>
        </article>
      )}

      {/* 2. About Us Page */}
      {view === 'about' && (
        <article className="prose prose-slate dark:prose-invert max-w-none space-y-6">
          <div className="border-b border-slate-200 pb-6 dark:border-slate-800">
            <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400 text-xs font-bold uppercase tracking-wider mb-2">
              <Sparkles className="h-4 w-4" />
              <span>Behind Ankush Picks</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-black text-slate-900 dark:text-white">
              About Ankush Picks
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">
              We cut through the noise to surface Amazon's true hidden gems and premier gear.
            </p>
          </div>

          <div className="space-y-4 text-sm sm:text-base text-slate-700 dark:text-slate-300 leading-relaxed">
            <p>
              Founded in 2026, Ankush Picks was built out of frustration with misleading Amazon search algorithms filled with unverified sponsored items and clone listings. Our mission is simple: <strong>provide transparent, hype-free product recommendations with genuine utility.</strong>
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 my-8 not-prose">
              <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
                <div className="h-10 w-10 rounded-xl bg-amber-100 flex items-center justify-center text-amber-700 dark:bg-amber-950 dark:text-amber-300 mb-3">
                  <ShieldCheck className="h-5 w-5" />
                </div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">Review Vetting</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  We filter out bot-generated and incentivized reviews, focusing on long-term user experiences.
                </p>
              </div>

              <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
                <div className="h-10 w-10 rounded-xl bg-emerald-100 flex items-center justify-center text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 mb-3">
                  <Sparkles className="h-5 w-5" />
                </div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">Value Driven</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  We look for gear with high durability that outlasts cheaper disposable alternatives.
                </p>
              </div>

              <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
                <div className="h-10 w-10 rounded-xl bg-blue-100 flex items-center justify-center text-blue-700 dark:bg-blue-950 dark:text-blue-300 mb-3">
                  <FileText className="h-5 w-5" />
                </div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">Zero Pay-to-Play</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Brands cannot pay for positive placement or higher star ratings in our catalog.
                </p>
              </div>
            </div>

            <h3 className="text-xl font-bold text-slate-900 dark:text-white mt-6">
              Our 4-Step Selection Process
            </h3>
            <ol className="list-decimal pl-5 space-y-2">
              <li><strong>Market Screening:</strong> We track best-sellers, top category movers, and new releases.</li>
              <li><strong>Authenticity Verification:</strong> We cross-reference independent third-party teardowns and verified buyer photo reviews.</li>
              <li><strong>Price History Check:</strong> We ensure current discounts represent genuine savings versus inflated original prices.</li>
              <li><strong>Direct Attribution:</strong> We connect buyers with direct, verified Amazon inventory links.</li>
            </ol>
          </div>
        </article>
      )}

      {/* 3. Contact Us Page */}
      {view === 'contact' && (
        <div className="space-y-8">
          <div className="border-b border-slate-200 pb-6 dark:border-slate-800">
            <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400 text-xs font-bold uppercase tracking-wider mb-2">
              <Mail className="h-4 w-4" />
              <span>Get In Touch</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-black text-slate-900 dark:text-white">
              Contact Ankush Picks
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">
              Have a product you want us to evaluate or a broken link to report? We reply within 24 hours.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            
            {/* Contact Form */}
            <div className="rounded-3xl border border-slate-200 bg-white p-6 sm:p-8 dark:border-slate-800 dark:bg-slate-900 shadow-sm">
              {contactSubmitted ? (
                <div className="text-center py-8 space-y-4">
                  <div className="h-14 w-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto dark:bg-emerald-950 dark:text-emerald-300">
                    <CheckCircle2 className="h-7 w-7" />
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white">Message Received!</h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xs mx-auto">
                    Thank you for reaching out. Our editorial team will review your note shortly.
                  </p>
                  <button
                    onClick={() => setContactSubmitted(false)}
                    className="text-xs font-bold text-amber-600 hover:underline dark:text-amber-400"
                  >
                    Send another message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleContactSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Your Name
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Jane Doe"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm text-slate-900 focus:border-amber-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Email Address
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="jane@example.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm text-slate-900 focus:border-amber-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Subject
                    </label>
                    <select
                      value={formData.subject}
                      onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                      className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm text-slate-900 focus:border-amber-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                    >
                      <option value="Product Question / Suggestion">Product Question / Suggestion</option>
                      <option value="Broken Link Report">Broken Amazon Link Report</option>
                      <option value="Partnership / Editorial Inquiry">Partnership / Editorial Inquiry</option>
                      <option value="General Feedback">General Feedback</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Your Message
                    </label>
                    <textarea
                      required
                      rows={4}
                      placeholder="Tell us what you're looking for or how we can assist..."
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="w-full rounded-xl border border-slate-300 px-3.5 py-2.5 text-sm text-slate-900 focus:border-amber-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                    />
                  </div>

                  <button
                    type="submit"
                    className="flex w-full items-center justify-center gap-2 rounded-xl bg-slate-900 py-3 text-sm font-bold text-white shadow-md hover:bg-slate-800 dark:bg-amber-500 dark:text-slate-950 dark:hover:bg-amber-400 transition-all"
                  >
                    <Send className="h-4 w-4" />
                    <span>Send Message</span>
                  </button>
                </form>
              )}
            </div>

            {/* Direct Info */}
            <div className="space-y-6">
              <div className="rounded-3xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
                <h3 className="text-base font-bold text-slate-900 dark:text-white mb-3">
                  Direct Inquiries
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
                  For corrections or Amazon Associates inquiries, you may reach our editorial desk directly:
                </p>
                <div className="space-y-2 text-xs text-slate-700 dark:text-slate-300">
                  <p><strong>Email:</strong> editorial@ankushpicks.com</p>
                  <p><strong>Response Time:</strong> 12–24 business hours</p>
                  <p><strong>Location:</strong> San Francisco, California, USA</p>
                </div>
              </div>

              <div className="rounded-3xl border border-amber-200 bg-amber-50/60 p-6 dark:border-amber-900 dark:bg-amber-950/30 text-xs text-amber-950 dark:text-amber-200">
                <h4 className="font-bold mb-1">Customer Service Notice:</h4>
                <p>
                  For orders, returns, delivery tracking, or warranties on purchased items, please contact Amazon Customer Support directly via your Amazon.com account dashboard.
                </p>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* 4. Privacy Policy */}
      {view === 'privacy' && (
        <article className="prose prose-slate dark:prose-invert max-w-none space-y-6">
          <div className="border-b border-slate-200 pb-6 dark:border-slate-800">
            <h1 className="text-3xl sm:text-4xl font-black text-slate-900 dark:text-white">
              Privacy Policy
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">
              Last updated: October 2026
            </p>
          </div>

          <div className="space-y-4 text-sm sm:text-base text-slate-700 dark:text-slate-300 leading-relaxed">
            <p>
              At Ankush Picks, we value and respect your personal privacy. This Privacy Policy outlines what information is collected when you visit our website and how it is used.
            </p>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white mt-6">
              1. Information We Do Not Collect
            </h3>
            <p>
              We do not collect credit card numbers, billing addresses, or shipping details. All payment processing, fulfillment, and checkout takes place exclusively on Amazon's secure servers.
            </p>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white mt-6">
              2. Cookies & Affiliate Tracking
            </h3>
            <p>
              When you click on an affiliate link to Amazon, Amazon places a temporary tracking cookie in your web browser. This cookie allows Amazon to recognize that you were referred by Ankush Picks so they can attribute eligible commissions. These cookies do not give us access to your personal account details or credit card information.
            </p>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white mt-6">
              3. Analytics & Device Info
            </h3>
            <p>
              We may utilize standard privacy-focused web analytics to evaluate traffic volume, top viewed product categories, and screen sizes to optimize our responsive layout.
            </p>
          </div>
        </article>
      )}

      {/* 5. Terms & Conditions */}
      {view === 'terms' && (
        <article className="prose prose-slate dark:prose-invert max-w-none space-y-6">
          <div className="border-b border-slate-200 pb-6 dark:border-slate-800">
            <h1 className="text-3xl sm:text-4xl font-black text-slate-900 dark:text-white">
              Terms & Conditions
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">
              Last updated: October 2026
            </p>
          </div>

          <div className="space-y-4 text-sm sm:text-base text-slate-700 dark:text-slate-300 leading-relaxed">
            <p>
              By accessing Ankush Picks, you agree to comply with and be bound by the following terms and conditions of use.
            </p>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white mt-6">
              1. Information Accuracy Disclaimer
            </h3>
            <p>
              The content provided on this website is for general informational and product discovery purposes only. Product prices, descriptions, specifications, and availability are subject to rapid change by Amazon and individual marketplace sellers.
            </p>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white mt-6">
              2. Limitation of Liability
            </h3>
            <p>
              Ankush Picks does not manufacture, sell, ship, or warrant any product listed on this website. All warranties, customer service requests, shipping inquiries, and refunds must be conducted directly through Amazon.com.
            </p>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white mt-6">
              3. Amazon Trademark Notice
            </h3>
            <p>
              Amazon, the Amazon logo, and Amazon Associates are trademarks of Amazon.com, Inc. or its affiliates.
            </p>
          </div>
        </article>
      )}

      {/* Back to Home Button */}
      <div className="mt-12 pt-6 border-t border-slate-200 dark:border-slate-800">
        <button
          onClick={onNavigateHome}
          className="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-5 py-2.5 text-xs font-bold text-white hover:bg-slate-800 dark:bg-amber-500 dark:text-slate-950 dark:hover:bg-amber-400"
        >
          ← Return to Curated Catalog
        </button>
      </div>

    </div>
  );
};
