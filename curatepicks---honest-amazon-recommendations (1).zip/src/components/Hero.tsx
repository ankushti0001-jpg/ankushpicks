import React from 'react';
import { Search, ShieldCheck, CheckCircle2, TrendingUp, Sparkles, Flame, ArrowRight, DollarSign } from 'lucide-react';
import { Category } from '../types';

interface HeroProps {
  searchQuery: string;
  onSearchChange: (q: string) => void;
  categories: Category[];
  selectedCategory: string;
  onSelectCategory: (cat: string) => void;
  onBrowseDeals: () => void;
  onViewAllProducts: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  searchQuery,
  onSearchChange,
  categories,
  selectedCategory,
  onSelectCategory,
  onBrowseDeals,
  onViewAllProducts
}) => {
  return (
    <div className="relative overflow-hidden bg-gradient-to-b from-amber-500/10 via-slate-50 to-white pt-10 pb-12 dark:from-amber-950/20 dark:via-slate-950 dark:to-slate-900 border-b border-slate-200/60 dark:border-slate-800">
      {/* Background Subtle Ambient Glow */}
      <div className="pointer-events-none absolute -top-24 left-1/2 h-96 w-96 -translate-x-1/2 rounded-full bg-amber-400/20 blur-3xl dark:bg-amber-600/10"></div>

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto">
          
          {/* Badge */}
          <div className="inline-flex items-center gap-2 rounded-full border border-amber-300/80 bg-amber-100/70 px-3.5 py-1 text-xs font-bold text-amber-900 shadow-sm dark:border-amber-700/60 dark:bg-amber-950/60 dark:text-amber-300 mb-6">
            <Sparkles className="h-3.5 w-3.5 text-amber-600 dark:text-amber-400" />
            <span>Ankush Picks • Verified Deals & Top Products</span>
            <span className="h-1 w-1 rounded-full bg-amber-600"></span>
            <span className="text-amber-700 dark:text-amber-400 font-semibold">Amazon India Store</span>
          </div>

          {/* Heading */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight text-slate-900 dark:text-white leading-[1.15]">
            Best Products, <br className="hidden sm:block" />
            <span className="bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 bg-clip-text text-transparent dark:from-amber-400 dark:via-orange-400 dark:to-amber-500">
              Amazon Recommendations.
            </span>
          </h1>

          {/* Tagline / Subtitle */}
          <p className="mt-4 text-base sm:text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto leading-relaxed">
            Hand-curated top-rated products and exclusive price drops directly from Amazon India. Click on any product to buy with full Amazon Prime benefits, cash on delivery, and rapid doorstep delivery.
          </p>

          {/* Hero Search Box */}
          <div className="mt-8 max-w-2xl mx-auto">
            <div className="flex flex-col sm:flex-row items-center gap-2 p-1.5 rounded-2xl bg-white border border-slate-200/90 shadow-xl shadow-slate-200/50 dark:bg-slate-900 dark:border-slate-700 dark:shadow-none">
              <div className="relative flex-1 w-full flex items-center">
                <Search className="ml-3.5 h-5 w-5 text-slate-400 dark:text-slate-500 shrink-0" />
                <input
                  type="text"
                  placeholder="Search products (e.g., AirPods, Ergonomic Chair, Air Fryer)..."
                  value={searchQuery}
                  onChange={(e) => onSearchChange(e.target.value)}
                  className="w-full bg-transparent px-3 py-3 text-sm sm:text-base text-slate-900 placeholder-slate-400 focus:outline-none dark:text-white dark:placeholder-slate-500"
                />
              </div>

              <div className="flex w-full sm:w-auto items-center gap-2">
                <button
                  onClick={onViewAllProducts}
                  className="w-full sm:w-auto rounded-xl bg-slate-900 px-6 py-3 text-sm font-bold text-white shadow-md hover:bg-slate-800 transition-all dark:bg-amber-500 dark:text-slate-950 dark:hover:bg-amber-400 shrink-0"
                >
                  Explore Catalog
                </button>
              </div>
            </div>
          </div>

          {/* Quick CTA Actions */}
          <div className="mt-4 flex flex-wrap items-center justify-center gap-3 text-xs sm:text-sm font-semibold">
            <a
              href="https://www.amazon.in?tag=ankushtiwari0-21&linkCode=ll2&linkId=d9b1693a55beb506b3a11b1e85cbbb90&ref_=as_li_ss_tl"
              target="_blank"
              rel="noopener noreferrer sponsored"
              className="inline-flex items-center gap-1.5 rounded-lg bg-amber-500 px-3.5 py-1.5 text-white hover:bg-amber-600 shadow-sm transition-all font-bold"
            >
              <span>Shop Everything on Amazon.in</span>
              <span className="text-[10px] bg-amber-700/60 px-1 rounded">Official</span>
            </a>

            <button
              onClick={onBrowseDeals}
              className="inline-flex items-center gap-1.5 rounded-lg bg-orange-100/90 px-3 py-1.5 text-orange-900 hover:bg-orange-200 dark:bg-orange-950/60 dark:text-orange-300 transition-colors"
            >
              <Flame className="h-4 w-4 text-orange-500 fill-orange-500" />
              <span>Today's Top Deals (Up to 78% Off)</span>
            </button>
            <span className="text-slate-300 dark:text-slate-700">•</span>
            <button
              onClick={() => onSelectCategory('')}
              className="text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white underline underline-offset-4"
            >
              View All Categories
            </button>
          </div>

          {/* Trust Guarantees */}
          <div className="mt-10 grid grid-cols-2 sm:grid-cols-4 gap-4 border-t border-slate-200/80 pt-8 dark:border-slate-800 text-left">
            <div className="flex items-start gap-2.5">
              <div className="rounded-lg bg-emerald-100 p-2 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 shrink-0">
                <ShieldCheck className="h-4 w-4" />
              </div>
              <div>
                <p className="text-xs font-bold text-slate-900 dark:text-white">Editorially Vetted</p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">Strict quality criteria only</p>
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <div className="rounded-lg bg-amber-100 p-2 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 shrink-0">
                <DollarSign className="h-4 w-4" />
              </div>
              <div>
                <p className="text-xs font-bold text-slate-900 dark:text-white">Verified Pricing</p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">Direct Amazon listings</p>
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <div className="rounded-lg bg-blue-100 p-2 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 shrink-0">
                <TrendingUp className="h-4 w-4" />
              </div>
              <div>
                <p className="text-xs font-bold text-slate-900 dark:text-white">Authentic Ratings</p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">4.5+ average score</p>
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <div className="rounded-lg bg-purple-100 p-2 text-purple-700 dark:bg-purple-950/60 dark:text-purple-300 shrink-0">
                <CheckCircle2 className="h-4 w-4" />
              </div>
              <div>
                <p className="text-xs font-bold text-slate-900 dark:text-white">Direct Affiliate</p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">Safe official checkout</p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
