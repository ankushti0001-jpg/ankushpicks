import React, { useState } from 'react';
import {
  X,
  Lock,
  Plus,
  Trash2,
  Edit2,
  Check,
  Upload,
  Link,
  DollarSign,
  Star,
  Tag,
  ShieldCheck,
  RefreshCw,
  Download,
  AlertCircle,
  ExternalLink,
  Eye,
  LogOut,
  FolderPlus
} from 'lucide-react';
import { Category, Product } from '../types';
import { storageService } from '../services/storage';

interface AdminModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  categories: Category[];
  onRefreshData: () => void;
  isAdmin: boolean;
  onLoginSuccess: () => void;
  onLogout: () => void;
}

export const AdminModal: React.FC<AdminModalProps> = ({
  isOpen,
  onClose,
  products,
  categories,
  onRefreshData,
  isAdmin,
  onLoginSuccess,
  onLogout
}) => {
  // Login form state
  const [passcode, setPasscode] = useState('');
  const [loginError, setLoginError] = useState('');

  // Active Tab
  const [activeTab, setActiveTab] = useState<'products' | 'new-product' | 'categories' | 'backup'>('products');

  // Product Editing state
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Product Form state
  const [formData, setFormData] = useState({
    name: '',
    category: categories[0]?.name || 'Electronics',
    price: '',
    originalPrice: '',
    rating: '4.8',
    reviewCount: '150',
    shortDescription: '',
    fullDescription: '',
    keyFeatures: '',
    affiliateUrl: '',
    imageUrl: '',
    isFeatured: false,
    isBestSeller: false,
    isTrending: false,
    status: 'published' as 'published' | 'draft',
    badge: ''
  });

  // Category Form state
  const [newCatName, setNewCatName] = useState('');
  const [newCatDesc, setNewCatDesc] = useState('');

  // Feedback notifications
  const [statusMessage, setStatusMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  if (!isOpen) return null;

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setStatusMessage({ text, type });
    setTimeout(() => setStatusMessage(null), 3500);
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (storageService.loginAdmin(passcode)) {
      onLoginSuccess();
      setPasscode('');
      setLoginError('');
      showToast('Admin authenticated successfully');
    } else {
      setLoginError('Invalid passcode. Default passcode is admin123');
    }
  };

  const handleEditClick = (p: Product) => {
    setEditingProduct(p);
    setFormData({
      name: p.name,
      category: p.category,
      price: p.price.toString(),
      originalPrice: p.originalPrice ? p.originalPrice.toString() : '',
      rating: p.rating.toString(),
      reviewCount: p.reviewCount.toString(),
      shortDescription: p.shortDescription,
      fullDescription: p.fullDescription || '',
      keyFeatures: (p.keyFeatures || []).join('\n'),
      affiliateUrl: p.affiliateUrl,
      imageUrl: p.imageUrl,
      isFeatured: p.isFeatured,
      isBestSeller: p.isBestSeller,
      isTrending: p.isTrending || false,
      status: p.status,
      badge: p.badge || ''
    });
    setActiveTab('new-product');
  };

  const resetForm = () => {
    setEditingProduct(null);
    setFormData({
      name: '',
      category: categories[0]?.name || 'Electronics',
      price: '',
      originalPrice: '',
      rating: '4.8',
      reviewCount: '150',
      shortDescription: '',
      fullDescription: '',
      keyFeatures: '',
      affiliateUrl: '',
      imageUrl: '',
      isFeatured: false,
      isBestSeller: false,
      isTrending: false,
      status: 'published',
      badge: ''
    });
  };

  const handleImageFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        showToast('Image size exceeds 5MB limit', 'error');
        return;
      }
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setFormData((prev) => ({ ...prev, imageUrl: event.target!.result as string }));
          showToast('Image uploaded successfully');
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name.trim() || !formData.affiliateUrl.trim() || !formData.price) {
      showToast('Name, Price, and Amazon Affiliate URL are required', 'error');
      return;
    }

    const priceNum = parseFloat(formData.price);
    const originalPriceNum = formData.originalPrice ? parseFloat(formData.originalPrice) : undefined;
    const ratingNum = parseFloat(formData.rating) || 4.5;
    const reviewsNum = parseInt(formData.reviewCount, 10) || 0;

    const featuresList = formData.keyFeatures
      .split('\n')
      .map((f) => f.trim())
      .filter(Boolean);

    const defaultImg = formData.imageUrl.trim() || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80';

    if (editingProduct) {
      // Update existing
      storageService.updateProduct(editingProduct.id, {
        name: formData.name.trim(),
        category: formData.category,
        price: priceNum,
        originalPrice: originalPriceNum,
        rating: ratingNum,
        reviewCount: reviewsNum,
        shortDescription: formData.shortDescription.trim() || formData.name,
        fullDescription: formData.fullDescription.trim(),
        keyFeatures: featuresList,
        affiliateUrl: formData.affiliateUrl.trim(),
        imageUrl: defaultImg,
        isFeatured: formData.isFeatured,
        isBestSeller: formData.isBestSeller,
        isTrending: formData.isTrending,
        status: formData.status,
        badge: formData.badge.trim()
      });
      showToast('Product updated successfully');
    } else {
      // Add new
      storageService.addProduct({
        name: formData.name.trim(),
        category: formData.category,
        price: priceNum,
        originalPrice: originalPriceNum,
        rating: ratingNum,
        reviewCount: reviewsNum,
        shortDescription: formData.shortDescription.trim() || formData.name,
        fullDescription: formData.fullDescription.trim(),
        keyFeatures: featuresList,
        affiliateUrl: formData.affiliateUrl.trim(),
        imageUrl: defaultImg,
        isFeatured: formData.isFeatured,
        isBestSeller: formData.isBestSeller,
        isTrending: formData.isTrending,
        status: formData.status,
        badge: formData.badge.trim()
      });
      showToast('Product created successfully');
    }

    resetForm();
    onRefreshData();
    setActiveTab('products');
  };

  const handleDeleteProduct = (id: string, name: string) => {
    if (window.confirm(`Are you sure you want to delete "${name}"?`)) {
      storageService.deleteProduct(id);
      onRefreshData();
      showToast('Product deleted');
    }
  };

  const handleAddCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;
    storageService.addCategory(newCatName.trim(), newCatDesc.trim());
    setNewCatName('');
    setNewCatDesc('');
    onRefreshData();
    showToast('Category created');
  };

  const handleDeleteCategory = (id: string, name: string) => {
    if (window.confirm(`Delete category "${name}"?`)) {
      storageService.deleteCategory(id);
      onRefreshData();
      showToast('Category deleted');
    }
  };

  const handleResetCatalog = () => {
    if (window.confirm('Reset catalog to factory default products and categories?')) {
      storageService.resetDefaults();
      onRefreshData();
      showToast('Catalog restored to default');
    }
  };

  const handleExportJson = () => {
    const data = {
      products: storageService.getProducts(),
      categories: storageService.getCategories(),
      exportedAt: new Date().toISOString()
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ankushpicks-catalog-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Catalog JSON exported');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto bg-slate-950/75 backdrop-blur-md">
      <div className="relative w-full max-w-5xl max-h-[92vh] flex flex-col overflow-hidden rounded-3xl bg-white shadow-2xl dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
        
        {/* Top Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-200/80 px-6 py-4 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
          <div className="flex items-center gap-3">
            <div className="rounded-xl bg-amber-500/10 p-2 text-amber-600 dark:text-amber-400">
              <Lock className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">
                Admin Product Management
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Manage Amazon affiliate products, categories, pricing, and live inventory
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {isAdmin && (
              <button
                onClick={() => {
                  onLogout();
                  showToast('Logged out of admin');
                }}
                className="flex items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
              >
                <LogOut className="h-3.5 w-3.5" />
                <span>Log Out</span>
              </button>
            )}

            <button
              onClick={onClose}
              className="rounded-full p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-slate-200"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Toast status banner */}
        {statusMessage && (
          <div
            className={`px-6 py-2.5 text-xs font-semibold flex items-center gap-2 ${
              statusMessage.type === 'error'
                ? 'bg-rose-500 text-white'
                : 'bg-emerald-600 text-white'
            }`}
          >
            <Check className="h-4 w-4" />
            <span>{statusMessage.text}</span>
          </div>
        )}

        {/* Admin Login Screen if not authenticated */}
        {!isAdmin ? (
          <div className="p-8 sm:p-12 max-w-md mx-auto text-center space-y-6">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-amber-100 text-amber-600 dark:bg-amber-950/60 dark:text-amber-400">
              <ShieldCheck className="h-7 w-7" />
            </div>

            <div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-white">
                Admin Authentication
              </h3>
              <p className="mt-1.5 text-xs text-slate-500 dark:text-slate-400">
                Enter your admin master key to add products, edit Amazon affiliate URLs, and manage categories.
              </p>
            </div>

            <form onSubmit={handleLogin} className="space-y-4 text-left">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1">
                  Passcode
                </label>
                <input
                  type="password"
                  placeholder="Enter passcode (default: admin123)"
                  value={passcode}
                  onChange={(e) => setPasscode(e.target.value)}
                  className="w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm text-slate-900 focus:border-amber-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  autoFocus
                />
                {loginError && <p className="mt-1 text-xs text-rose-500">{loginError}</p>}
                <p className="mt-2 text-[11px] text-slate-400">
                  Tip: Default master passcode is <code className="bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded font-mono font-bold">admin123</code>.
                </p>
              </div>

              <button
                type="submit"
                className="w-full rounded-xl bg-slate-900 py-3 text-sm font-bold text-white shadow-md hover:bg-slate-800 dark:bg-amber-500 dark:text-slate-950 dark:hover:bg-amber-400 transition-all"
              >
                Sign In to Dashboard
              </button>
            </form>
          </div>
        ) : (
          /* Authenticated Admin Area */
          <div className="flex-1 flex flex-col overflow-hidden">
            
            {/* Tab navigation */}
            <div className="flex items-center gap-2 border-b border-slate-200 px-6 pt-3 dark:border-slate-800 bg-slate-50/40 dark:bg-slate-900/40">
              <button
                onClick={() => setActiveTab('products')}
                className={`border-b-2 px-4 py-2.5 text-xs font-bold transition-colors ${
                  activeTab === 'products'
                    ? 'border-amber-500 text-amber-600 dark:text-amber-400'
                    : 'border-transparent text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
                }`}
              >
                Products ({products.length})
              </button>

              <button
                onClick={() => {
                  resetForm();
                  setActiveTab('new-product');
                }}
                className={`flex items-center gap-1.5 border-b-2 px-4 py-2.5 text-xs font-bold transition-colors ${
                  activeTab === 'new-product'
                    ? 'border-amber-500 text-amber-600 dark:text-amber-400'
                    : 'border-transparent text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
                }`}
              >
                <Plus className="h-3.5 w-3.5" />
                <span>{editingProduct ? 'Edit Product' : 'Add New Product'}</span>
              </button>

              <button
                onClick={() => setActiveTab('categories')}
                className={`border-b-2 px-4 py-2.5 text-xs font-bold transition-colors ${
                  activeTab === 'categories'
                    ? 'border-amber-500 text-amber-600 dark:text-amber-400'
                    : 'border-transparent text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
                }`}
              >
                Categories ({categories.length})
              </button>

              <button
                onClick={() => setActiveTab('backup')}
                className={`border-b-2 px-4 py-2.5 text-xs font-bold transition-colors ${
                  activeTab === 'backup'
                    ? 'border-amber-500 text-amber-600 dark:text-amber-400'
                    : 'border-transparent text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
                }`}
              >
                Backup & Settings
              </button>
            </div>

            {/* Scrollable Tab Content */}
            <div className="flex-1 overflow-y-auto p-6">
              
              {/* TAB 1: Product List Table */}
              {activeTab === 'products' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                        All Registered Amazon Products
                      </h3>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        {products.length} products total • Affiliate links are strictly preserved
                      </p>
                    </div>

                    <button
                      onClick={() => {
                        resetForm();
                        setActiveTab('new-product');
                      }}
                      className="flex items-center gap-1.5 rounded-xl bg-amber-500 px-4 py-2 text-xs font-bold text-white shadow-sm hover:bg-amber-600"
                    >
                      <Plus className="h-4 w-4" />
                      <span>Add Product</span>
                    </button>
                  </div>

                  <div className="overflow-x-auto rounded-2xl border border-slate-200 dark:border-slate-800">
                    <table className="w-full text-left text-xs">
                      <thead className="border-b border-slate-200 bg-slate-50 text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:border-slate-800 dark:bg-slate-800/60 dark:text-slate-400">
                        <tr>
                          <th className="px-4 py-3">Product</th>
                          <th className="px-4 py-3">Category</th>
                          <th className="px-4 py-3">Price / MRP</th>
                          <th className="px-4 py-3">Rating</th>
                          <th className="px-4 py-3">Affiliate Link</th>
                          <th className="px-4 py-3">Status</th>
                          <th className="px-4 py-3 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                        {products.map((p) => (
                          <tr key={p.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40">
                            <td className="px-4 py-3">
                              <div className="flex items-center gap-3">
                                <img
                                  src={p.imageUrl}
                                  alt=""
                                  className="h-10 w-10 shrink-0 rounded-lg object-contain bg-slate-100 dark:bg-slate-800 p-1"
                                />
                                <div>
                                  <p className="font-bold text-slate-900 line-clamp-1 dark:text-white max-w-xs">
                                    {p.name}
                                  </p>
                                  <div className="flex items-center gap-2 mt-0.5">
                                    {p.isFeatured && (
                                      <span className="rounded bg-amber-100 px-1.5 py-0.2 text-[10px] font-bold text-amber-800 dark:bg-amber-950 dark:text-amber-300">
                                        Featured
                                      </span>
                                    )}
                                    {p.badge && (
                                      <span className="rounded bg-slate-100 px-1.5 py-0.2 text-[10px] text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                                        {p.badge}
                                      </span>
                                    )}
                                  </div>
                                </div>
                              </div>
                            </td>

                            <td className="px-4 py-3">
                              <span className="rounded-full bg-slate-100 px-2.5 py-1 text-[11px] font-medium text-slate-700 dark:bg-slate-800 dark:text-slate-300">
                                {p.category}
                              </span>
                            </td>

                            <td className="px-4 py-3 font-semibold text-slate-900 dark:text-white">
                              <div>₹{p.price.toLocaleString('en-IN')}</div>
                              {p.originalPrice && (
                                <div className="text-[10px] text-slate-400 line-through">
                                  ₹{p.originalPrice.toLocaleString('en-IN')}
                                </div>
                              )}
                            </td>

                            <td className="px-4 py-3">
                              <span className="font-semibold text-amber-600 dark:text-amber-400">
                                {p.rating} ★
                              </span>
                              <div className="text-[10px] text-slate-400">({p.reviewCount})</div>
                            </td>

                            <td className="px-4 py-3 max-w-[200px]">
                              <a
                                href={p.affiliateUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center gap-1 text-[11px] text-blue-600 hover:underline truncate dark:text-blue-400"
                                title={p.affiliateUrl}
                              >
                                <span className="truncate">{p.affiliateUrl}</span>
                                <ExternalLink className="h-3 w-3 shrink-0" />
                              </a>
                            </td>

                            <td className="px-4 py-3">
                              <span
                                className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${
                                  p.status === 'published'
                                    ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300'
                                    : 'bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-400'
                                }`}
                              >
                                {p.status}
                              </span>
                            </td>

                            <td className="px-4 py-3 text-right">
                              <div className="flex items-center justify-end gap-1.5">
                                <button
                                  onClick={() => handleEditClick(p)}
                                  className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-800 dark:hover:bg-slate-800 dark:hover:text-white"
                                  title="Edit"
                                >
                                  <Edit2 className="h-3.5 w-3.5" />
                                </button>
                                <button
                                  onClick={() => handleDeleteProduct(p.id, p.name)}
                                  className="rounded-lg p-1.5 text-rose-500 hover:bg-rose-50 hover:text-rose-700 dark:hover:bg-rose-950/40"
                                  title="Delete"
                                >
                                  <Trash2 className="h-3.5 w-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* TAB 2: Add / Edit Product Form */}
              {activeTab === 'new-product' && (
                <form onSubmit={handleSaveProduct} className="space-y-6 max-w-3xl">
                  <div className="flex items-center justify-between border-b border-slate-200 pb-3 dark:border-slate-800">
                    <h3 className="text-base font-bold text-slate-900 dark:text-white">
                      {editingProduct ? `Edit: ${editingProduct.name}` : 'Add New Amazon Product'}
                    </h3>
                    {editingProduct && (
                      <button
                        type="button"
                        onClick={resetForm}
                        className="text-xs font-semibold text-slate-500 hover:text-slate-800 dark:hover:text-white"
                      >
                        Cancel Edit
                      </button>
                    )}
                  </div>

                  {/* Amazon Affiliate URL */}
                  <div className="rounded-2xl border-2 border-amber-400/50 bg-amber-50/40 p-4 dark:border-amber-500/30 dark:bg-amber-950/20">
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-xs font-extrabold uppercase tracking-wider text-amber-900 dark:text-amber-300">
                        Amazon Associates Affiliate URL *
                      </label>
                      <span className="rounded-md bg-amber-200/80 px-2 py-0.5 text-[10px] font-bold text-amber-900 dark:bg-amber-900/60 dark:text-amber-200">
                        Affiliate Tag: ankushtiwari0-21
                      </span>
                    </div>
                    <p className="text-xs text-amber-800/80 dark:text-amber-400 mb-2">
                      Enter your Amazon affiliate link. Purchases through this link will generate commissions for your Associates account.
                    </p>
                    <div className="flex flex-col sm:flex-row items-center gap-2">
                      <div className="flex-1 w-full flex items-center gap-2">
                        <Link className="h-4 w-4 text-amber-600 dark:text-amber-400 shrink-0" />
                        <input
                          type="url"
                          placeholder="https://www.amazon.in/dp/B0XXXXXXXX?tag=ankushtiwari0-21"
                          value={formData.affiliateUrl}
                          onChange={(e) => setFormData({ ...formData, affiliateUrl: e.target.value })}
                          required
                          className="w-full rounded-xl border border-amber-300 bg-white px-3 py-2 text-xs sm:text-sm text-slate-900 focus:border-amber-500 focus:outline-none dark:border-amber-700 dark:bg-slate-800 dark:text-white"
                        />
                      </div>
                      {formData.affiliateUrl && !formData.affiliateUrl.includes('tag=ankushtiwari0-21') && (
                        <button
                          type="button"
                          onClick={() => {
                            const separator = formData.affiliateUrl.includes('?') ? '&' : '?';
                            setFormData({
                              ...formData,
                              affiliateUrl: `${formData.affiliateUrl}${separator}tag=ankushtiwari0-21&linkCode=ll2`
                            });
                            showToast('Attached tag=ankushtiwari0-21 to URL');
                          }}
                          className="shrink-0 rounded-xl bg-amber-500 px-3 py-2 text-xs font-bold text-white hover:bg-amber-600 shadow-sm"
                        >
                          + Attach Tag (ankushtiwari0-21)
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Basic Info */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                        Product Title / Name *
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. boAt Airdopes 141 Bluetooth Truly Wireless Earbuds"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        required
                        className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm text-slate-900 focus:border-amber-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                        Category *
                      </label>
                      <select
                        value={formData.category}
                        onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                        className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm text-slate-900 focus:border-amber-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                      >
                        {categories.map((c) => (
                          <option key={c.id} value={c.name}>
                            {c.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                        Badge / Label (Optional)
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Bestseller, 73% Off Deal, Top Rated"
                        value={formData.badge}
                        onChange={(e) => setFormData({ ...formData, badge: e.target.value })}
                        className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-sm text-slate-900 focus:border-amber-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                      />
                    </div>
                  </div>

                  {/* Pricing and Ratings */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                        Current Price (₹) *
                      </label>
                      <input
                        type="number"
                        step="1"
                        placeholder="1199"
                        value={formData.price}
                        onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                        required
                        className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-amber-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                        Original/MRP (₹)
                      </label>
                      <input
                        type="number"
                        step="1"
                        placeholder="4490"
                        value={formData.originalPrice}
                        onChange={(e) => setFormData({ ...formData, originalPrice: e.target.value })}
                        className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-amber-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                        Rating (0 - 5.0)
                      </label>
                      <input
                        type="number"
                        step="0.1"
                        min="1"
                        max="5"
                        placeholder="4.8"
                        value={formData.rating}
                        onChange={(e) => setFormData({ ...formData, rating: e.target.value })}
                        className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-amber-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                        Review Count
                      </label>
                      <input
                        type="number"
                        placeholder="1500"
                        value={formData.reviewCount}
                        onChange={(e) => setFormData({ ...formData, reviewCount: e.target.value })}
                        className="w-full rounded-xl border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-amber-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                      />
                    </div>
                  </div>

                  {/* Image input (URL + File Upload) */}
                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                      Product Image (Image URL or File Upload)
                    </label>
                    <div className="flex flex-col sm:flex-row gap-3 items-center">
                      <input
                        type="url"
                        placeholder="https://images.unsplash.com/... or Amazon image URL"
                        value={formData.imageUrl}
                        onChange={(e) => setFormData({ ...formData, imageUrl: e.target.value })}
                        className="w-full flex-1 rounded-xl border border-slate-300 px-3.5 py-2 text-xs sm:text-sm text-slate-900 focus:border-amber-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                      />
                      <label className="flex items-center gap-1.5 rounded-xl border border-slate-300 bg-slate-50 px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 cursor-pointer dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 shrink-0">
                        <Upload className="h-3.5 w-3.5 text-slate-500" />
                        <span>Upload File</span>
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={handleImageFileUpload}
                        />
                      </label>
                    </div>

                    {formData.imageUrl && (
                      <div className="mt-2 flex items-center gap-3">
                        <img
                          src={formData.imageUrl}
                          alt="Preview"
                          className="h-16 w-16 rounded-xl object-contain border border-slate-200 dark:border-slate-700 p-1 bg-white dark:bg-slate-800"
                        />
                        <span className="text-xs text-emerald-600 font-semibold flex items-center gap-1">
                          <Check className="h-3.5 w-3.5" /> Image ready
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Descriptions */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Short Description (Card Summary)
                    </label>
                    <textarea
                      rows={2}
                      placeholder="Brief punchy summary shown on product card..."
                      value={formData.shortDescription}
                      onChange={(e) => setFormData({ ...formData, shortDescription: e.target.value })}
                      className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-xs sm:text-sm text-slate-900 focus:border-amber-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Full Description (Product Page Details)
                    </label>
                    <textarea
                      rows={3}
                      placeholder="In-depth editorial review and product background..."
                      value={formData.fullDescription}
                      onChange={(e) => setFormData({ ...formData, fullDescription: e.target.value })}
                      className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-xs sm:text-sm text-slate-900 focus:border-amber-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Key Highlights / Features (One feature per line)
                    </label>
                    <textarea
                      rows={3}
                      placeholder="Next-level Active Noise Cancellation&#10;Up to 30 hours battery life&#10;USB-C Fast Charging"
                      value={formData.keyFeatures}
                      onChange={(e) => setFormData({ ...formData, keyFeatures: e.target.value })}
                      className="w-full rounded-xl border border-slate-300 px-3.5 py-2 text-xs sm:text-sm text-slate-900 focus:border-amber-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                    />
                  </div>

                  {/* Toggles */}
                  <div className="flex flex-wrap items-center gap-6 rounded-2xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-800/50">
                    <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.isFeatured}
                        onChange={(e) => setFormData({ ...formData, isFeatured: e.target.checked })}
                        className="h-4 w-4 rounded text-amber-500 focus:ring-amber-400"
                      />
                      <span>Featured Product (Spotlight)</span>
                    </label>

                    <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.isBestSeller}
                        onChange={(e) => setFormData({ ...formData, isBestSeller: e.target.checked })}
                        className="h-4 w-4 rounded text-amber-500 focus:ring-amber-400"
                      />
                      <span>Best Seller</span>
                    </label>

                    <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.isTrending}
                        onChange={(e) => setFormData({ ...formData, isTrending: e.target.checked })}
                        className="h-4 w-4 rounded text-amber-500 focus:ring-amber-400"
                      />
                      <span>Trending</span>
                    </label>

                    <div className="flex items-center gap-2 ml-auto">
                      <span className="text-xs font-bold text-slate-700 dark:text-slate-300">Status:</span>
                      <select
                        value={formData.status}
                        onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                        className="rounded-lg border border-slate-300 bg-white px-2 py-1 text-xs font-semibold dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                      >
                        <option value="published">Published</option>
                        <option value="draft">Draft (Hidden)</option>
                      </select>
                    </div>
                  </div>

                  {/* Submit Button */}
                  <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200 dark:border-slate-800">
                    <button
                      type="button"
                      onClick={() => setActiveTab('products')}
                      className="rounded-xl border border-slate-300 px-5 py-2.5 text-xs font-bold text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="rounded-xl bg-amber-500 px-6 py-2.5 text-xs font-extrabold text-white shadow-md hover:bg-amber-600 transition-all"
                    >
                      {editingProduct ? 'Save Changes' : 'Publish Product'}
                    </button>
                  </div>
                </form>
              )}

              {/* TAB 3: Category Management */}
              {activeTab === 'categories' && (
                <div className="space-y-6 max-w-2xl">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                      Manage Store Categories
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      Add, view, and organize product categories used for filtering across the site.
                    </p>
                  </div>

                  {/* Add category form */}
                  <form onSubmit={handleAddCategory} className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Category name (e.g., Outdoor, Smart Home)..."
                      value={newCatName}
                      onChange={(e) => setNewCatName(e.target.value)}
                      className="flex-1 rounded-xl border border-slate-300 px-3.5 py-2 text-xs sm:text-sm text-slate-900 focus:border-amber-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                    />
                    <button
                      type="submit"
                      className="flex items-center gap-1.5 rounded-xl bg-slate-900 px-4 py-2 text-xs font-bold text-white hover:bg-slate-800 dark:bg-amber-500 dark:text-slate-950 dark:hover:bg-amber-400"
                    >
                      <FolderPlus className="h-4 w-4" />
                      <span>Add Category</span>
                    </button>
                  </form>

                  {/* Category List */}
                  <div className="divide-y divide-slate-100 rounded-2xl border border-slate-200 dark:divide-slate-800 dark:border-slate-800">
                    {categories.map((c) => {
                      const count = products.filter((p) => p.category === c.name).length;
                      return (
                        <div key={c.id} className="flex items-center justify-between p-3 sm:p-4 hover:bg-slate-50 dark:hover:bg-slate-800/40">
                          <div>
                            <p className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                              {c.name}
                            </p>
                            <p className="text-[11px] text-slate-500 dark:text-slate-400">
                              {count} {count === 1 ? 'product' : 'products'} assigned
                            </p>
                          </div>
                          <button
                            onClick={() => handleDeleteCategory(c.id, c.name)}
                            className="rounded-lg p-1.5 text-slate-400 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-950/40"
                            title="Delete category"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* TAB 4: Backup & Settings */}
              {activeTab === 'backup' && (
                <div className="space-y-6 max-w-2xl">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                      Catalog Backup & Data Management
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      Export catalog JSON, restore initial seed products, or verify your affiliate configuration.
                    </p>
                  </div>

                  <div className="rounded-2xl border border-slate-200 bg-slate-50/50 p-5 space-y-4 dark:border-slate-800 dark:bg-slate-800/40">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <p className="text-xs font-bold text-slate-900 dark:text-white">
                          Export Catalog Backup (JSON)
                        </p>
                        <p className="text-xs text-slate-500 dark:text-slate-400">
                          Download a complete JSON file with all your curated products, categories, and affiliate URLs.
                        </p>
                      </div>
                      <button
                        onClick={handleExportJson}
                        className="flex items-center gap-1.5 rounded-xl border border-slate-300 bg-white px-3.5 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 shrink-0"
                      >
                        <Download className="h-4 w-4" />
                        <span>Export JSON</span>
                      </button>
                    </div>

                    <div className="border-t border-slate-200 pt-4 dark:border-slate-700 flex items-start justify-between gap-4">
                      <div>
                        <p className="text-xs font-bold text-slate-900 dark:text-white">
                          Restore Factory Seed Products
                        </p>
                        <p className="text-xs text-slate-500 dark:text-slate-400">
                          Reset the catalog back to 12 curated products and 10 default categories.
                        </p>
                      </div>
                      <button
                        onClick={handleResetCatalog}
                        className="flex items-center gap-1.5 rounded-xl border border-rose-300 bg-rose-50 px-3.5 py-2 text-xs font-bold text-rose-700 hover:bg-rose-100 dark:border-rose-900 dark:bg-rose-950/40 dark:text-rose-300 shrink-0"
                      >
                        <RefreshCw className="h-4 w-4" />
                        <span>Reset Defaults</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}

            </div>

          </div>
        )}

      </div>
    </div>
  );
};
