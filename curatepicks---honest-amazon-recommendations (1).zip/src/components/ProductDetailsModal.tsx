import React, { useState } from 'react';
import {
  X,
  Star,
  ExternalLink,
  ShoppingBag,
  CheckCircle2,
  ShieldCheck,
  Share2,
  Tag,
  Info,
  ArrowLeft,
  Flame,
  Clock,
  Sparkles,
  Copy,
  Check
} from 'lucide-react';
import { Product } from '../types';

interface ProductDetailsModalProps {
  product: Product | null;
  onClose: () => void;
  onSelectCategory: (cat: string) => void;
  relatedProducts: Product[];
  onViewProduct: (prod: Product) => void;
}

export const ProductDetailsModal: React.FC<ProductDetailsModalProps> = ({
  product,
  onClose,
  onSelectCategory,
  relatedProducts,
  onViewProduct
}) => {
  const [copied, setCopied] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  if (!product) return null;

  const currentImage = selectedImage || product.imageUrl;
  const allImages = [product.imageUrl, ...(product.additionalImages || [])];

  const discountVal = product.discountPercentage ?? (
    product.originalPrice && product.originalPrice > product.price
      ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
      : null
  );

  const formatPrice = (val: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(val);
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(product.affiliateUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 md:p-6 overflow-y-auto bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden rounded-3xl bg-white shadow-2xl dark:bg-slate-900 border border-slate-200 dark:border-slate-800"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Sticky Header Bar */}
        <div className="flex items-center justify-between border-b border-slate-200/80 px-4 py-3 sm:px-6 dark:border-slate-800 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 dark:text-slate-400">
            <button
              onClick={onClose}
              className="flex items-center gap-1 hover:text-slate-900 dark:hover:text-white"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              <span>Back to recommendations</span>
            </button>
            <span>/</span>
            <button
              onClick={() => {
                onSelectCategory(product.category);
                onClose();
              }}
              className="text-amber-600 hover:underline dark:text-amber-400"
            >
              {product.category}
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyLink}
              className="flex items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800 transition-colors"
              title="Copy Amazon affiliate link"
            >
              {copied ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
              <span>{copied ? 'Copied' : 'Share Link'}</span>
            </button>

            <button
              onClick={onClose}
              className="rounded-full p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-slate-200"
              aria-label="Close product view"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-8 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
            
            {/* Left: Product Media Gallery */}
            <div className="space-y-4">
              <div className="relative aspect-square w-full overflow-hidden rounded-2xl border border-slate-200/80 bg-slate-50 p-6 flex items-center justify-center dark:border-slate-800 dark:bg-slate-800/50">
                {product.badge && (
                  <span className="absolute top-3 left-3 z-10 inline-flex items-center gap-1 rounded-full bg-slate-900 px-3 py-1 text-xs font-bold text-white shadow-md dark:bg-amber-400 dark:text-slate-950">
                    <Flame className="h-3 w-3 text-amber-400 dark:text-slate-950" />
                    {product.badge}
                  </span>
                )}
                {discountVal && discountVal > 0 ? (
                  <span className="absolute top-3 right-3 z-10 inline-flex items-center rounded-full bg-rose-600 px-3 py-1 text-xs font-bold text-white shadow-md">
                    -{discountVal}% OFF
                  </span>
                ) : null}

                <img
                  src={currentImage}
                  alt={product.name}
                  className="max-h-full max-w-full object-contain transition-transform duration-300 hover:scale-105"
                />
              </div>

              {/* Thumbnails */}
              {allImages.length > 1 && (
                <div className="flex gap-2 overflow-x-auto pb-1">
                  {allImages.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setSelectedImage(img)}
                      className={`h-16 w-16 shrink-0 overflow-hidden rounded-xl border-2 p-1 bg-white dark:bg-slate-800 ${
                        currentImage === img
                          ? 'border-amber-500 ring-2 ring-amber-500/20'
                          : 'border-slate-200 dark:border-slate-700 opacity-70 hover:opacity-100'
                      }`}
                    >
                      <img src={img} alt="" className="h-full w-full object-contain" />
                    </button>
                  ))}
                </div>
              )}

              {/* Guarantee Box */}
              <div className="rounded-xl border border-emerald-200 bg-emerald-50/60 p-3.5 text-xs text-emerald-900 dark:border-emerald-900/60 dark:bg-emerald-950/30 dark:text-emerald-300 flex items-start gap-2.5">
                <ShieldCheck className="h-4 w-4 shrink-0 text-emerald-600 dark:text-emerald-400 mt-0.5" />
                <div>
                  <p className="font-bold">Verified Amazon Affiliate Partner Link</p>
                  <p className="mt-0.5 text-emerald-700 dark:text-emerald-400">
                    Purchases are safely fulfilled directly through Amazon with full buyer protection and Prime delivery perks.
                  </p>
                </div>
              </div>
            </div>

            {/* Right: Product Details & CTA */}
            <div className="flex flex-col justify-between space-y-6">
              <div>
                {/* Category & ASIN */}
                <div className="flex items-center gap-2 mb-2">
                  <span className="rounded-md bg-slate-100 px-2.5 py-0.5 text-xs font-semibold text-slate-700 dark:bg-slate-800 dark:text-slate-300">
                    {product.category}
                  </span>
                  {product.asin && (
                    <span className="text-xs font-mono text-slate-400 dark:text-slate-500">
                      ASIN: {product.asin}
                    </span>
                  )}
                </div>

                {/* Title */}
                <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white leading-tight">
                  {product.name}
                </h1>

                {/* Rating & Review stats */}
                <div className="mt-3 flex items-center gap-3">
                  <div className="flex items-center gap-1 text-amber-500">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className={`h-4 w-4 ${
                          star <= Math.round(product.rating)
                            ? 'fill-amber-400 text-amber-400'
                            : 'text-slate-300 dark:text-slate-600'
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-sm font-bold text-slate-800 dark:text-slate-200">
                    {product.rating.toFixed(1)} out of 5
                  </span>
                  {product.reviewCount > 0 && (
                    <>
                      <span className="text-slate-300 dark:text-slate-600">•</span>
                      <span className="text-sm text-slate-500 dark:text-slate-400">
                        {product.reviewCount.toLocaleString()} Amazon ratings
                      </span>
                    </>
                  )}
                </div>

                {/* Price Display */}
                <div className="mt-5 rounded-2xl bg-slate-50 p-4 border border-slate-200/80 dark:bg-slate-800/40 dark:border-slate-700/60">
                  <div className="flex items-baseline gap-3">
                    <span className="text-3xl font-black text-slate-900 dark:text-white">
                      {formatPrice(product.price)}
                    </span>
                    {product.originalPrice && product.originalPrice > product.price && (
                      <span className="text-base text-slate-400 line-through">
                        {formatPrice(product.originalPrice)}
                      </span>
                    )}
                    {discountVal && discountVal > 0 && (
                      <span className="rounded-md bg-rose-100 px-2 py-0.5 text-xs font-bold text-rose-700 dark:bg-rose-950/60 dark:text-rose-300">
                        Save {discountVal}%
                      </span>
                    )}
                  </div>
                  <p className="mt-1.5 text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                    <Clock className="h-3 w-3 text-slate-400" />
                    <span>Price and availability may change on Amazon. Live pricing verified today.</span>
                  </p>
                </div>

                {/* Prominent Buy on Amazon Button */}
                <div className="mt-6 space-y-2">
                  <a
                    href={product.affiliateUrl}
                    target="_blank"
                    rel="noopener noreferrer sponsored"
                    className="flex w-full items-center justify-center gap-2.5 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-600 to-orange-500 py-4 px-6 text-base font-extrabold text-white shadow-xl shadow-amber-500/25 hover:from-amber-600 hover:to-orange-600 hover:shadow-2xl active:scale-[0.99] transition-all text-center"
                  >
                    <ShoppingBag className="h-5 w-5" />
                    <span>Buy on Amazon</span>
                    <ExternalLink className="h-4 w-4 opacity-80" />
                  </a>

                  {/* Required Clear Affiliate Disclosure */}
                  <div className="rounded-xl bg-amber-50/80 p-3 text-xs leading-relaxed text-amber-900 border border-amber-200/80 dark:bg-amber-950/40 dark:border-amber-900/50 dark:text-amber-200 flex items-start gap-2">
                    <Info className="h-4 w-4 shrink-0 text-amber-600 dark:text-amber-400 mt-0.5" />
                    <span>
                      <strong>Affiliate Disclosure:</strong> Some links on this website are affiliate links. If you purchase through these links, we may earn a commission at no additional cost to you.
                    </span>
                  </div>
                </div>

                {/* Summary Description */}
                <div className="mt-6">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-2">
                    Overview
                  </h3>
                  <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                    {product.fullDescription || product.shortDescription}
                  </p>
                </div>

                {/* Key Features Bullet Points */}
                {product.keyFeatures && product.keyFeatures.length > 0 && (
                  <div className="mt-6">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-2.5">
                      Key Highlights & Features
                    </h3>
                    <ul className="space-y-2">
                      {product.keyFeatures.map((feat, i) => (
                        <li key={i} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-700 dark:text-slate-300">
                          <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                          <span>{feat}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>

          </div>

          {/* Related Products in this category */}
          {relatedProducts.length > 0 && (
            <div className="mt-10 border-t border-slate-200 pt-8 dark:border-slate-800">
              <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-4">
                Similar Recommendations in {product.category}
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {relatedProducts.slice(0, 3).map((rel) => (
                  <div
                    key={rel.id}
                    onClick={() => onViewProduct(rel)}
                    className="cursor-pointer rounded-xl border border-slate-200 p-3 hover:border-amber-400 transition-all dark:border-slate-800 dark:hover:border-amber-500/50 flex items-center gap-3 bg-white dark:bg-slate-800/40"
                  >
                    <img src={rel.imageUrl} alt={rel.name} className="h-16 w-16 object-contain rounded-lg bg-slate-50 dark:bg-slate-800 p-1" />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-bold text-slate-900 truncate dark:text-white">{rel.name}</p>
                      <p className="text-xs font-extrabold text-amber-600 dark:text-amber-400 mt-1">{formatPrice(rel.price)}</p>
                      <p className="text-[11px] text-slate-400 mt-0.5">{rel.rating} ★ ({rel.reviewCount})</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
