import React from 'react';
import {
  SlidersHorizontal,
  Flame,
  ArrowUpDown,
  Star,
  X,
  Sparkles,
  Check
} from 'lucide-react';
import { Category, SortOption } from '../types';

interface FiltersBarProps {
  categories: Category[];
  selectedCategory: string;
  onSelectCategory: (cat: string) => void;
  selectedSort: SortOption;
  onSelectSort: (sort: SortOption) => void;
  minRating: number;
  onSelectMinRating: (rating: number) => void;
  dealsOnly: boolean;
  onToggleDealsOnly: () => void;
  totalResults: number;
  onResetFilters: () => void;
  hasActiveFilters: boolean;
}

export const FiltersBar: React.FC<FiltersBarProps> = ({
  categories,
  selectedCategory,
  onSelectCategory,
  selectedSort,
  onSelectSort,
  minRating,
  onSelectMinRating,
  dealsOnly,
  onToggleDealsOnly,
  totalResults,
  onResetFilters,
  hasActiveFilters
}) => {
  return (
    <div className="w-full space-y-4">
      
      {/* Category Pills Slider / Row */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        <button
          onClick={() => onSelectCategory('')}
          className={`shrink-0 rounded-full px-4 py-2 text-xs sm:text-sm font-bold transition-all shadow-sm ${
            selectedCategory === ''
              ? 'bg-slate-900 text-white dark:bg-amber-400 dark:text-slate-950 shadow-md'
              : 'bg-white text-slate-700 hover:bg-slate-100 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700'
          }`}
        >
          All Categories
        </button>

        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => onSelectCategory(cat.name)}
            className={`shrink-0 rounded-full px-4 py-2 text-xs sm:text-sm font-semibold transition-all ${
              selectedCategory === cat.name
                ? 'bg-amber-500 text-white shadow-md shadow-amber-500/20'
                : 'bg-white text-slate-700 hover:bg-slate-100 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700'
            }`}
          >
            {cat.name}
          </button>
        ))}
      </div>

      {/* Second Row: Filters, Deals Toggle, Sort dropdown, and Count */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-slate-200/80 bg-white p-3 sm:p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        
        {/* Left Side: Deals Toggle & Rating Filter */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Best Deals Switch */}
          <button
            onClick={onToggleDealsOnly}
            className={`flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-bold transition-all ${
              dealsOnly
                ? 'bg-orange-500 text-white shadow-md shadow-orange-500/25 ring-2 ring-orange-400/30'
                : 'border border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300'
            }`}
          >
            <Flame className={`h-3.5 w-3.5 ${dealsOnly ? 'fill-white' : 'text-orange-500'}`} />
            <span>Discounted Deals Only</span>
          </button>

          {/* Rating filter selector */}
          <div className="flex items-center gap-1">
            <span className="text-xs font-semibold text-slate-400 dark:text-slate-500 hidden sm:inline">
              Rating:
            </span>
            <div className="flex items-center rounded-xl border border-slate-200 bg-slate-50 p-1 dark:border-slate-700 dark:bg-slate-800">
              {[
                { label: 'Any', value: 0 },
                { label: '4.5+ ★', value: 4.5 },
                { label: '4.8+ ★', value: 4.8 }
              ].map((opt) => (
                <button
                  key={opt.value}
                  onClick={() => onSelectMinRating(opt.value)}
                  className={`rounded-lg px-2.5 py-1 text-xs font-semibold transition-colors ${
                    minRating === opt.value
                      ? 'bg-white text-slate-900 shadow-sm dark:bg-slate-700 dark:text-white'
                      : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Reset Filters button if any active */}
          {hasActiveFilters && (
            <button
              onClick={onResetFilters}
              className="flex items-center gap-1 text-xs font-semibold text-rose-600 hover:text-rose-700 dark:text-rose-400 ml-1"
            >
              <X className="h-3.5 w-3.5" />
              <span>Clear Filters</span>
            </button>
          )}
        </div>

        {/* Right Side: Sorting & Product Match Count */}
        <div className="flex items-center gap-3 ml-auto">
          <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
            <strong className="text-slate-900 dark:text-white">{totalResults}</strong> {totalResults === 1 ? 'product' : 'products'}
          </span>

          <div className="flex items-center gap-1.5">
            <ArrowUpDown className="h-3.5 w-3.5 text-slate-400" />
            <select
              value={selectedSort}
              onChange={(e) => onSelectSort(e.target.value as SortOption)}
              className="rounded-xl border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs font-semibold text-slate-800 focus:border-amber-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
            >
              <option value="featured">Featured Picks</option>
              <option value="rating-desc">Highest Rated</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="discount-desc">Biggest Discount</option>
              <option value="newest">Newest Added</option>
            </select>
          </div>
        </div>

      </div>
    </div>
  );
};
