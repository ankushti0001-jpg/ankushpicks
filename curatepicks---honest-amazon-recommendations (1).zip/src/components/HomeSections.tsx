import React from 'react';
import { Product } from '../types';
import { ProductCard } from './ProductCard';
import { Sparkles, TrendingUp, Star, Clock, Flame, ArrowRight } from 'lucide-react';

interface HomeSectionsProps {
  products: Product[];
  onViewDetails: (product: Product) => void;
  onCategoryClick: (category: string) => void;
  onExploreMore: () => void;
}

export const HomeSections: React.FC<HomeSectionsProps> = ({
  products,
  onViewDetails,
  onCategoryClick,
  onExploreMore
}) => {
  // Published products only
  const published = products.filter((p) => p.status === 'published');

  // Featured Products
  const featured = published.filter((p) => p.isFeatured).slice(0, 4);

  // Trending Products (marked isTrending or high reviews)
  const trending = published
    .filter((p) => p.isTrending || p.reviewCount > 15000)
    .slice(0, 4);

  // Best Rated Products (rating >= 4.7 sorted desc)
  const bestRated = [...published]
    .sort((a, b) => b.rating - a.rating || b.reviewCount - a.reviewCount)
    .slice(0, 4);

  // Latest Products (by creation date or reverse order)
  const latest = [...published]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 4);

  return (
    <div className="space-y-16">
      
      {/* 1. Featured Products Section */}
      {featured.length > 0 && (
        <section aria-labelledby="featured-heading">
          <div className="flex items-end justify-between mb-6">
            <div>
              <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400 text-xs font-extrabold uppercase tracking-wider mb-1">
                <Sparkles className="h-4 w-4" />
                <span>Editor's Selection</span>
              </div>
              <h2 id="featured-heading" className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
                Featured Products
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
                Hand-tested, best-in-class picks that deliver unmatched value and durability.
              </p>
            </div>
            <button
              onClick={onExploreMore}
              className="hidden sm:flex items-center gap-1 text-xs font-bold text-amber-600 hover:text-amber-700 dark:text-amber-400 dark:hover:text-amber-300"
            >
              <span>View All</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featured.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onViewDetails={onViewDetails}
                onCategoryClick={onCategoryClick}
              />
            ))}
          </div>
        </section>
      )}

      {/* 2. Trending Products Section */}
      {trending.length > 0 && (
        <section aria-labelledby="trending-heading">
          <div className="flex items-end justify-between mb-6">
            <div>
              <div className="flex items-center gap-2 text-orange-600 dark:text-orange-400 text-xs font-extrabold uppercase tracking-wider mb-1">
                <Flame className="h-4 w-4" />
                <span>Viral & Most Purchased</span>
              </div>
              <h2 id="trending-heading" className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
                Trending Products
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
                High-demand products with immense popularity and customer satisfaction.
              </p>
            </div>
            <button
              onClick={onExploreMore}
              className="hidden sm:flex items-center gap-1 text-xs font-bold text-orange-600 hover:text-orange-700 dark:text-orange-400"
            >
              <span>Explore</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {trending.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onViewDetails={onViewDetails}
                onCategoryClick={onCategoryClick}
              />
            ))}
          </div>
        </section>
      )}

      {/* 3. Best Rated Products Section */}
      {bestRated.length > 0 && (
        <section aria-labelledby="best-rated-heading">
          <div className="flex items-end justify-between mb-6">
            <div>
              <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 text-xs font-extrabold uppercase tracking-wider mb-1">
                <Star className="h-4 w-4 fill-emerald-500 text-emerald-500" />
                <span>Customer Verified</span>
              </div>
              <h2 id="best-rated-heading" className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
                Best Rated Products
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
                Highest customer review scores across thousands of genuine verified purchases.
              </p>
            </div>
            <button
              onClick={onExploreMore}
              className="hidden sm:flex items-center gap-1 text-xs font-bold text-emerald-600 hover:text-emerald-700 dark:text-emerald-400"
            >
              <span>See Top Rated</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {bestRated.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onViewDetails={onViewDetails}
                onCategoryClick={onCategoryClick}
              />
            ))}
          </div>
        </section>
      )}

      {/* 4. Latest Products Section */}
      {latest.length > 0 && (
        <section aria-labelledby="latest-heading">
          <div className="flex items-end justify-between mb-6">
            <div>
              <div className="flex items-center gap-2 text-blue-600 dark:text-blue-400 text-xs font-extrabold uppercase tracking-wider mb-1">
                <Clock className="h-4 w-4" />
                <span>Recently Added</span>
              </div>
              <h2 id="latest-heading" className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
                Latest Products
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
                Fresh recommendations and newly published buyer reviews.
              </p>
            </div>
            <button
              onClick={onExploreMore}
              className="hidden sm:flex items-center gap-1 text-xs font-bold text-blue-600 hover:text-blue-700 dark:text-blue-400"
            >
              <span>All Releases</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {latest.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onViewDetails={onViewDetails}
                onCategoryClick={onCategoryClick}
              />
            ))}
          </div>
        </section>
      )}

    </div>
  );
};
