export interface Product {
  id: string;
  name: string;
  slug: string;
  shortDescription: string;
  fullDescription?: string;
  keyFeatures?: string[];
  price: number;
  originalPrice?: number;
  discountPercentage?: number;
  rating: number;
  reviewCount: number;
  category: string;
  affiliateUrl: string; // Exact Amazon affiliate URL entered
  imageUrl: string;
  additionalImages?: string[];
  isFeatured: boolean;
  isBestSeller: boolean;
  isTrending?: boolean;
  status: 'published' | 'draft';
  badge?: string; // e.g. "Editor's Pick", "Top Deal", "Best Value"
  asin?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description?: string;
  iconName?: string;
}

export type SortOption =
  | 'featured'
  | 'rating-desc'
  | 'price-asc'
  | 'price-desc'
  | 'discount-desc'
  | 'newest';

export interface FilterState {
  searchQuery: string;
  category: string;
  minRating: number;
  priceRange: [number, number];
  sortBy: SortOption;
  dealsOnly: boolean;
}

export type PageView =
  | 'home'
  | 'categories'
  | 'deals'
  | 'product'
  | 'about'
  | 'contact'
  | 'disclosure'
  | 'privacy'
  | 'terms'
  | 'admin';
